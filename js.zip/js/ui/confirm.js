import { sheetCloseButton } from './sheetClose.js';
import { italianUI as itUI } from '../i18n.js';
// js/ui/confirm.js
// Delete confirmation bottom sheet — mirrors bottomsheet_delete_boat_confirmation.xml

const WARN_ICON = `
<svg viewBox="0 0 24 24" width="24" height="24" fill="none"
     stroke="#FFFFFF" stroke-width="1.8"
     stroke-linecap="round" stroke-linejoin="round">
  <path d="M3 6h18"/>
  <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
  <path d="M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/>
  <line x1="10" y1="11" x2="10" y2="17"/>
  <line x1="14" y1="11" x2="14" y2="17"/>
</svg>`;

const TRASH_ICON = `
<svg viewBox="0 0 24 24" width="16" height="16" fill="none"
     stroke="#FFFFFF" stroke-width="2"
     stroke-linecap="round" stroke-linejoin="round">
  <path d="M3 6h18"/>
  <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
  <path d="M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/>
</svg>`;

/**
 * Show a confirmation sheet.
 * @param {Object} opts
 * @param {string} opts.title       e.g. "Delete boat"
 * @param {string} opts.message     e.g. "This vessel will be permanently removed."
 * @param {string} [opts.confirmText='Delete']
 * @param {string} [opts.cancelText='Cancel']
 * @param {string} [opts.icon] Trusted SVG markup for both action icons
 * @returns {Promise<boolean>}      true if confirmed, false if cancelled
 */
export function confirmSheet(opts) {
  const {
    title       = 'Are you sure?',
    message     = '',
    confirmText = 'Delete',
    cancelText  = 'Cancel',
    action = 'delete',
    icon,
    signal
  } = opts;

  return new Promise((resolve) => {
    if (signal?.aborted) { resolve(false); return; }
    const opener = document.activeElement;
    const backdrop = document.createElement('div');
    backdrop.className = 'confirm-backdrop';

    const sheet = document.createElement('div');
    sheet.className = 'confirm-sheet';
    const neutralAction = action === 'confirm';
    const archiveAction = action === 'archive' || action === 'restore';
    if (archiveAction) sheet.classList.add('confirm-sheet--archive');
    if (action === 'approve') sheet.classList.add('confirm-sheet--approve');
    const actionIcon = icon ?? (action === 'approve' ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>` : archiveAction ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h16v13H4zM3 3h18v5H3z"/><path d="${action === 'restore' ? 'M12 17v-6m-3 3 3-3 3 3' : 'M9 12h6'}"/></svg>` : null);
    sheet.innerHTML = `
      ${sheetCloseButton()}

      ${neutralAction ? '' : `<div class="confirm-warn-circle">${actionIcon || WARN_ICON}</div>`}

      <div class="confirm-title">${escapeHtml(itUI(title))}</div>
      <div class="confirm-message">${escapeHtml(itUI(message))}</div>

      <div class="confirm-actions">
        <button class="confirm-btn confirm-btn--cancel" type="button">
          ${escapeHtml(itUI(cancelText))}
        </button>
        <button class="confirm-btn${neutralAction ? '' : ' confirm-btn--confirm'}" data-confirm-action type="button"
          ${neutralAction ? 'style="background:var(--color-water-blue,#2196F3);color:var(--color-bg);font-weight:700;"' : ''}>
          ${neutralAction ? '' : actionIcon || TRASH_ICON}<span>${escapeHtml(itUI(confirmText))}</span>
        </button>
      </div>
    `;

    document.getElementById('modalRoot').append(backdrop, sheet);

    requestAnimationFrame(() => {
      backdrop.classList.add('is-open');
      sheet.classList.add('is-open');
    });

    let settled = false;
    function close(result) {
      if (settled) return;
      settled = true;
      document.removeEventListener('keydown', onKey);
      signal?.removeEventListener('abort', onAbort);
      if (opener?.isConnected) opener.focus();
      backdrop.classList.remove('is-open');
      sheet.classList.remove('is-open');
      setTimeout(() => {
        backdrop.remove();
        sheet.remove();
      }, 220);
      resolve(result);
    }

    const onAbort = () => close(false);
    const onKey = event => {
      if (event.key === 'Escape') close(false);
      if (event.key === 'Tab') {
        const first = sheet.querySelector('[data-sheet-close]');
        const last = sheet.querySelector('[data-confirm-action]');
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    signal?.addEventListener('abort', onAbort, {once: true});
    document.addEventListener('keydown', onKey);
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    sheet.setAttribute('aria-label', title);
    sheet.querySelector('.confirm-btn--cancel').focus();

    sheet.querySelector('.confirm-btn--cancel').addEventListener('click', () => close(false));
    sheet.querySelector('[data-confirm-action]').addEventListener('click', () => close(true));
    backdrop.addEventListener('click', () => close(false));
    sheet.querySelector('[data-sheet-close]').addEventListener('click', () => close(false));
  });
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}