import { italianUI as itUI } from '../i18n.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
// js/screens/AboutSheet.js

const APP_NAME = 'MarinaControl';
const EXTERNAL_URL = 'https://sites.google.com/view/fethiyemarina/home/';

export function showAboutSheet({ yacht = false, onClose } = {}) {
  const title = yacht ? tr('Yacht Management') : APP_NAME;
  const description = yacht
    ? tr('MarinaControl Yacht Management gives yacht owners and crew one place to manage vessel details, maintenance, safety, equipment, inventory, checklists, tasks and documents.')
    : tr("MarinaControl gives marinas a single place to manage boats, berths, crew and customers — from daily operations to compliance.");
  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'sheet';

  sheet.innerHTML = `
   <div class="invoice-sheet-header"
  style="position:sticky;top:0;z-index:2;flex-shrink:0;display:flex;align-items:center;min-height:48px;background:var(--color-surface, #1C222A);">

  <div class="sheet-title"
    style="flex:1;margin:0;padding:12px 48px;text-align:center;">

  </div>

  <button type="button" id="iv-close" aria-label="${itUI("Close about sheet")}"
    style="position:absolute;right:0;top:2px;display:grid;place-items:center;width:44px;height:44px;padding:0;border:0;border-radius:8px;background:transparent;color:#F5F7F9;cursor:pointer;">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
      stroke="currentColor" stroke-width="2" stroke-linecap="round"
      aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18"/>
    </svg>
  </button>
</div>

    <div class="about-body">
      <div class="about-logo">
        <img src="assets/logo.png" alt="${itUI("MarinaControl")}" onerror="this.style.display='none'">
      </div>

      <div class="about-name">${title}</div>
 

      <div class="about-desc">${description}</div>

      <div class="about-divider"></div>

      <div class="about-links">
        <button type="button" class="about-link" id="aboutTerms">${tr("Terms")}</button>
        <div class="about-link-sep"></div>
        <button type="button" class="about-link" id="aboutPrivacy">${tr("Privacy")}</button>
      </div>

           <button type="button" class="about-close" id="aboutClose">${tr("Close")}</button>
    </div>
  `;

  document.getElementById('modalRoot').append(backdrop, sheet);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    onClose?.();
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); sheet.remove(); }, 220);
  };

  backdrop.addEventListener('click', close);
  sheet.querySelector('#aboutClose').addEventListener('click', close);
  sheet.querySelector('#iv-close').addEventListener('click', close);

  sheet.querySelector('#aboutTerms').addEventListener('click', () => {
    window.open(EXTERNAL_URL, '_blank', 'noopener');
  });

  sheet.querySelector('#aboutPrivacy').addEventListener('click', () => {
    window.open(EXTERNAL_URL, '_blank', 'noopener');
  });
}