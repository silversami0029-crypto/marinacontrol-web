import { italianUI as itUI } from '../i18n.js';
import {confirmMarinaLifecycle, lifecycleText as lt} from './MarinaLifecycleSheet.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
import { t, getLocale, languagePicker, getLanguage } from '../i18n.js';
// js/screens/ManageMarinasSheet.js
import { store } from '../store.js';
import { auth } from '../firebase.js';
import { getMyMarinas } from '../db.js';
import { esc } from '../utils.js';
import { getFunctions, httpsCallable } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-functions.js';

const functions = getFunctions(auth.app, 'us-central1');
let openSheet = null;
const buttonStyle = 'padding:12px;border:1px solid #737D89;border-radius:8px;background:#151A20;color:#F5F7F9;font:inherit;cursor:pointer;';
const inviteText = (en, ar) => getLanguage() === 'ar' ? ar : itUI(en);
const inputStyle = 'box-sizing:border-box;width:100%;margin-top:5px;padding:11px;border:1px solid #737D89;border-radius:7px;background:#151A20;color:#F5F7F9;font:inherit;';

export function showManageMarinasSheet() {
  if (openSheet || !store.authUser) return;
  const cssUrl = new URL('../../css/marina-lifecycle.css', import.meta.url).href;
  if (![...document.querySelectorAll('link[rel=stylesheet]')].some(link => link.href === cssUrl)) {
    const link = document.createElement('link'); link.rel = 'stylesheet'; link.href = cssUrl; document.head.append(link);
  }
  const uid = store.authUser.uid;
  const sourceClientId = Number(store.activeClientId);
  const canCreate = (store.activeRole || store.userProfile?.role) === 'admin';
  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';
  const sheet = document.createElement('div');
  sheet.className = 'sheet marina-manage-sheet';
  sheet.setAttribute('role', 'dialog');
  sheet.setAttribute('aria-modal', 'true');
  sheet.setAttribute('aria-labelledby', 'mmTitle');
  sheet.innerHTML = `
    <div class="marina-sheet-header ml-header">
      <h2 id="mmTitle" class="sheet-title">${t('Manage Marinas')}</h2>
      <button type="button" id="mmHeaderClose" class="ml-header-close" aria-label="${t('Close')}">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <div class="ml-body">
      <label class="ml-visibility">${lt('Show', 'عرض')}
        <select id="mmVisibility">
          <option value="active">${lt('Active marinas', 'المارينات النشطة')}</option>
          <option value="archived">${lt('Archived marinas', 'المارينات المؤرشفة')}</option>
          <option value="all">${lt('All marinas', 'كل المارينات')}</option>
        </select>
      </label>
      <div id="mmList" class="ml-list"></div>
      <div id="mmActions" class="ml-tools">
        ${canCreate ? `<button type="button" id="mmAdd" style="${buttonStyle}">${t('Add Marina')}</button>` : ''}
        <button type="button" id="mmJoin" style="${buttonStyle}">${t('Join Marina')}</button>
        <button type="button" id="mmRefresh" style="${buttonStyle}">${t('Refresh List')}</button>
      </div>
      <div id="mmForm"></div>
      <p id="mmStatus" class="ml-status" role="status" aria-live="polite" hidden></p>
    </div>
    <div class="ml-footer">
      <button type="button" id="mmClose" style="${buttonStyle}width:100%;">${t('Close')}</button>
    </div>`;
  const root = document.getElementById('modalRoot');
  if (!root) return;
  root.append(backdrop, sheet);
  openSheet = sheet;
  const priorFocus = document.activeElement;
  let busy = false, deletionRunning = false, loadingManaged = false, hasManaged = false;
  let managed = [...store.marinas];
  const $ = selector => sheet.querySelector(selector);
  function validSession() {
    if (store.authUser?.uid !== uid || Number(store.activeClientId) !== sourceClientId) {
      throw new Error(tr('Your active marina changed. Close this sheet and try again.'));
    }
  }
  function status(message, error = false) {
    $('#mmStatus').textContent = message;
    $('#mmStatus').hidden = !message;
    $('#mmStatus').style.color = error ? '#FF8A80' : '#AEB6C1';
  }
  function setBusy(value) {
    busy = value;
    sheet.querySelectorAll('button,input').forEach(el => { el.disabled = value; });
  }
  function close() {
    if (busy && !deletionRunning && !loadingManaged) return;
    sheet.remove(); backdrop.remove(); openSheet = null;
    document.removeEventListener('keydown', onKey);
    if (priorFocus?.isConnected) priorFocus.focus();
  }
  function onKey(event) {
    if (document.querySelector('.marina-lifecycle-confirm')) return;
    if (event.key === 'Escape') { event.preventDefault(); close(); }
    if (event.key !== 'Tab') return;
    const items = [...sheet.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled)')].filter(el => el.offsetParent !== null);
    const first = items[0], last = items.at(-1);
    if (!first) { event.preventDefault(); return; }
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
  document.addEventListener('keydown', onKey);
  backdrop.addEventListener('click', close);
  $('#mmClose').addEventListener('click', close);
  $('#mmHeaderClose').addEventListener('click', close);
  requestAnimationFrame(() => {
    if (!sheet.isConnected) return;
    backdrop.classList.add('is-open'); sheet.classList.add('is-open');
    sheet.querySelector('button')?.focus();
  });
  function renderList() {
    const visibility = $('#mmVisibility').value;
    const visible = managed.filter(m => visibility === 'all' || (visibility === 'archived' ? m.archived || m.lifecycle === 'DELETING' : Number(m.isActive) === 1 && !m.archived));
    $('#mmList').innerHTML = visible.map(m => `
      <div style="border:1px solid #0A8EF7;border-radius:10px;padding:14px;background:#172532;">
        <strong>${esc(m.name)}</strong>
        ${m.lifecycle === 'DELETING' ? `<div class="ml-state">${lt('Deletion in progress', 'الحذف قيد التنفيذ')}</div>` : m.archived ? `<div class="ml-state">${lt('Archived', 'مؤرشفة')}</div>` : ''}
        <div style="color:#AEB6C1;font-size:13px;margin-top:4px;">${esc(t(m.role || 'staff'))}${Number(m.id) === sourceClientId ? ' · ' + t('Active') : ''}</div>
        ${Number(m.id) !== sourceClientId && Number(m.isActive) === 1 && !m.archived ? `<button type="button" data-switch="${Number(m.id)}" style="${buttonStyle}margin-top:8px;">${t("Switch to Marina")}</button>` : ''}
        ${m.role === 'admin' && Number(m.isActive) === 1 && !m.archived ? `
          <div style="display:flex;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-top:8px;">
            <button type="button" data-invite="${Number(m.id)}" style="${buttonStyle}">${t("Show Invite Code")}</button>
            <div data-invite-panel="${Number(m.id)}" hidden style="flex:1;min-width:200px;border:1px solid #0A8EF7;border-radius:8px;padding:10px;background:#151A20;">
              <div data-invite-message role="status" aria-live="polite" style="font-size:13px;overflow-wrap:anywhere;"></div>
              <div data-invite-controls hidden>
                <label style="display:block;font-size:12px;margin-top:8px;">${t('Invite Code:')}
                  <input data-invite-code readonly aria-label="${t('Invite code')}" style="${inputStyle}direction:ltr;text-align:center;font-weight:700;font-size:18px;letter-spacing:2px;">
                </label>
                <button type="button" data-copy-invite style="${buttonStyle}margin-top:8px;width:100%;">${t('Copy')}</button>
              </div>
            </div>
          </div>` : ''}
        ${m.role === 'admin' ? `<div class="ml-actions">${m.lifecycle === 'DELETING' ? (m.canResume ? `<button type="button" data-resume="${Number(m.id)}" style="${buttonStyle}">${lt('Resume deletion', 'استئناف الحذف')}</button>` : '') : `<button type="button" data-lifecycle="${m.archived ? 'RESTORE' : 'ARCHIVE'}" data-marina="${Number(m.id)}" style="${buttonStyle}color:var(--accent-teal,#26A69A);">${m.archived ? lt('Restore marina', 'استعادة المارينا') : lt('Archive marina', 'أرشفة المارينا')}</button><button type="button" data-lifecycle="DELETE" data-marina="${Number(m.id)}" style="${buttonStyle}color:var(--color-danger,#FF8A80);">${lt('Delete marina', 'حذف المارينا')}</button>`}</div>` : ''}
      </div>`).join('') || `<p class="ml-empty">${!hasManaged ? lt('Loading marinas…', 'جارٍ تحميل المارينات…') : visibility === 'archived' ? lt('No archived marinas.', 'لا توجد مارينات مؤرشفة.') : lt('No marinas in this view.', 'لا توجد مارينات في هذا العرض.')}</p>`;
    $('#mmList').querySelectorAll('[data-lifecycle]').forEach(button => button.onclick = () => run(async () => {
      const clientId = Number(button.dataset.marina), action = button.dataset.lifecycle;
      const preview = await call('getMarinaLifecyclePreview', {clientId, sourceClientId});
      if (action !== 'RESTORE' && preview.blocked) { status(preview.blocked, true); return; }
      const confirmation = await confirmMarinaLifecycle(preview, action);
      if (!confirmation || !sheet.isConnected) return;
      validSession();
      await call('changeMarinaLifecycle', {clientId, sourceClientId, revision: preview.revision, action, ...confirmation});
      if (action === 'DELETE') { await loadManaged(); await resumeDeletion(clientId); }
      else { await loadManaged(); status(action === 'RESTORE' ? lt('Marina restored.', 'تمت استعادة المارينا.') : lt('Marina archived. Its records are preserved.', 'تمت أرشفة المارينا مع الاحتفاظ بسجلاتها.')); }
    }));
    $('#mmList').querySelectorAll('[data-resume]').forEach(button => button.onclick = () => run(() => resumeDeletion(Number(button.dataset.resume))));
    $('#mmList').querySelectorAll('[data-switch]').forEach(btn => {
      btn.addEventListener('click', () => run(async () => {
        const { switchMarina } = await import('../router.js');
        await switchMarina(Number(btn.dataset.switch));
      }));
    });
    $('#mmList').querySelectorAll('[data-invite]').forEach(btn => {
      const panel = $('#mmList').querySelector(`[data-invite-panel="${btn.dataset.invite}"]`);
      const message = panel.querySelector('[data-invite-message]');
      const controls = panel.querySelector('[data-invite-controls]');
      const codeInput = panel.querySelector('[data-invite-code]');
      btn.addEventListener('click', async () => {
        if (busy) return;
        panel.hidden = false;
        controls.hidden = true;
        message.style.color = '#AEB6C1';
        message.textContent = inviteText('Loading invite code…', 'جارٍ تحميل رمز الدعوة…');
        setBusy(true);
        try {
          const result = await call('getMarinaInvite', {clientId: Number(btn.dataset.invite)});
          validSession();
          if (!sheet.isConnected) return;
          const code = String(result?.inviteCode || '').trim();
          if (!code) throw new Error(inviteText('No invite code returned. Please try again.', 'لم يتم إرجاع رمز دعوة. حاول مجدداً.'));
          codeInput.value = code;
          controls.hidden = false;
          message.textContent = inviteText('Anyone with this code can join as staff. Share it only with authorised colleagues.', 'يمكن لمن لديه هذا الرمز الانضمام كموظف. شاركه مع الزملاء المصرّح لهم فقط.');
        } catch (error) {
          console.error('[marina invite]', error);
          message.style.color = '#FF8A80';
          message.textContent = error.message || inviteText('Unable to load invite code. Please try again.', 'تعذّر تحميل رمز الدعوة. حاول مجدداً.');
        } finally {
          if (sheet.isConnected) setBusy(false);
        }
      });
      panel.querySelector('[data-copy-invite]').addEventListener('click', async () => {
        try {
          validSession();
          await navigator.clipboard.writeText(codeInput.value);
          message.style.color = '#3DD68C';
          message.textContent = t('Invite code copied');
        } catch {
          codeInput.focus();
          codeInput.select();
          message.style.color = '#AEB6C1';
          message.textContent = inviteText('Select and copy the code manually.', 'حدّد الرمز وانسخه يدوياً.');
        }
      });
    });
  }
  async function loadManaged() {
    loadingManaged = true;
    $('#mmClose').disabled = false;
    $('#mmHeaderClose').disabled = false;
    try {
      const result = await call('listMarinaLifecycle', {});
      if (!sheet.isConnected) return;
      managed = result.marinas;
      hasManaged = true;
      store.marinas = managed.filter(m => Number(m.isActive) === 1 && !m.archived);
      renderList();
      status('');
    } finally { loadingManaged = false; }
  }
  async function resumeDeletion(clientId) {
    deletionRunning = true;
    try {
      while (sheet.isConnected) {
        validSession();
        setBusy(true); $('#mmClose').disabled = false; $('#mmHeaderClose').disabled = false;
        const result = await call('continueMarinaDeletion', {clientId});
        if (!sheet.isConnected) return;
        if (result.done) { await loadManaged(); status(lt('Test marina and linked records deleted.', 'تم حذف مارينا الاختبار وسجلاتها المرتبطة.')); return; }
        status(result.waiting ? lt('Deletion started. Waiting for earlier requests to finish. You can close this sheet and resume deletion later under Archived marinas.', 'بدأ الحذف. ننتظر انتهاء الطلبات السابقة. يمكنك إغلاق النافذة واستئناف الحذف لاحقاً ضمن المارينات المؤرشفة.') : lt('Deleting linked records… ', 'جارٍ حذف السجلات المرتبطة… ') + Number(result.deletedRoots || 0));
        await new Promise(resolve => setTimeout(resolve, Math.max(1000, Math.min(5000, Number(result.retryAfter || 1000)))));
      }
    } catch (error) {
      if (sheet.isConnected) { try { await loadManaged(); } catch {} }
      throw error;
    } finally { deletionRunning = false; }
  }
  async function call(name, data) {
    validSession();
    const timeout = /MarinaLifecycle|MarinaDeletion/.test(name) ? 550000 : 70000;
    const result = await httpsCallable(functions, name, {timeout})(data);
    validSession();
    return result.data;
  }
  async function run(action, waitingMessage = lt('Please wait…', 'يرجى الانتظار…')) {
    if (busy) return;
    setBusy(true); status(waitingMessage);
    try { validSession(); await action(); }
    catch (error) { console.error('[manage marinas]', error); status(error.message || itUI('Unable to complete this action.'), true); }
    finally { if (sheet.isConnected) setBusy(false); }
  }
  async function loadAndSwitch(id) {
    // The backend action has succeeded; do not encourage repeating marina creation.
    status('Marina saved. Loading your marina list…');
    try {
      await auth.currentUser.getIdToken(true);
      const marinas = (await getMyMarinas(uid, store.userProfile?.userId || 0))
        .filter(m => Number(m.isActive) === 1);
      validSession();
      store.marinas = marinas;
      if (!marinas.some(m => Number(m.id) === Number(id))) throw new Error(tr('New marina not yet visible'));
      // Storage failure must not repeat an already successful backend operation.
      localStorage.setItem(`marinacontrol.activeMarina.${uid}`, String(id));
      const route = location.hash.split('?')[0];
      const safeRoute = route === '#/boat-dashboard' ? '#/boats' : (route || '#/boats');
      history.replaceState(null, '', `${location.pathname}${location.search}${safeRoute}`);
      location.reload();
    } catch (error) {
      console.error('[manage marinas] refresh after save failed', error);
      status('Marina saved successfully. Close this sheet and refresh the WebApp to load it.');
      renderList();
    }
  }
  $('#mmRefresh').addEventListener('click', () => run(async () => {
    await loadManaged(); status(lt('Marina list refreshed.', 'تم تحديث قائمة المارينات.'));
  }));
  function showForm(mode) {
    const adding = mode === 'add';
    $('#mmForm').innerHTML = `
      <form id="mmDetails" style="display:grid;gap:12px;margin-top:16px;">
        ${adding ? `
          <label>${t("Marina name")}<input name="name" required maxlength="120" style="${inputStyle}"></label>
          <label>${t("Country code (e.g. ES, AE, GB)")}<input name="countryCode" required minlength="2" maxlength="2" pattern="[A-Za-z]{2}" style="${inputStyle}"></label>
          <label>${t("Email (optional)")}<input name="email" type="email" maxlength="254" style="${inputStyle}"></label>
          <label>${t("Phone (optional)")}<input name="phone" type="tel" maxlength="50" style="${inputStyle}"></label>
          <p style="margin:0;color:#AEB6C1;">${t("The new marina joins the current marina’s organisation. You will be its administrator.")}</p>
        ` : `
          <label>${t("Invite code")}<input name="inviteCode" required minlength="6" maxlength="32" pattern="[A-Za-z0-9]{6,32}" autocomplete="off" style="${inputStyle}"></label>
          <label>${t("Your name")}<input name="displayName" required minlength="2" maxlength="100" value="${esc(store.userProfile?.name || '')}" style="${inputStyle}"></label>
          <p style="margin:0;color:#AEB6C1;">${t("Use the invite code provided by that marina’s administrator. Joining requires a verified email.")}</p>
        `}
        <button type="submit" style="${buttonStyle}background:#0A8EF7;border-color:#0A8EF7;">${adding ? itUI('Create Marina') : tr('Join Marina')}</button>
      </form>`;
    status('');
    $('#mmDetails input')?.focus();
    $('#mmDetails').addEventListener('submit', event => {
      event.preventDefault();
      const data = Object.fromEntries(new FormData(event.currentTarget));
      run(async () => {
        const result = adding
          ? await call('createMarina', {...data, sourceClientId})
          : await call('redeemMarinaInvite', {...data, inviteCode: data.inviteCode.trim().toUpperCase()});
        // Prevent a second submission after a successful save, even if refresh fails.
        $('#mmForm').replaceChildren();
        await loadAndSwitch(result.marina?.id || result.client?.id);
      });
    });
  }
  $('#mmAdd')?.addEventListener('click', () => {
    $('#mmForm').innerHTML = `
      <h3 style="margin:18px 0 12px;">${t("Add Marina")}</h3>
      <div style="display:grid;gap:10px;">
        <button type="button" id="mmSingle" style="${buttonStyle}text-align:left;">${t("Add Single Marina")}<br><small>${t("Add one marina manually")}</small></button>
        <button type="button" id="mmBulk" style="${buttonStyle}text-align:left;">${t("Bulk Import")}<br><small>${t("Import multiple marinas from a CSV file")}</small></button>
      </div>`;
    status('');
    $('#mmSingle').addEventListener('click', () => showForm('add'));
    $('#mmBulk').addEventListener('click', showBulkForm);
    $('#mmSingle').focus();
  });
  function showBulkForm() {
    $('#mmForm').innerHTML = `
      <form id="mmBulkForm" style="display:grid;gap:12px;margin-top:18px;">
        <h3 style="margin:0;">${t("Bulk Import Marinas")}</h3>
        <p style="margin:0;color:#AEB6C1;">${t("CSV columns: name,countryCode,email,phone. Name and two-letter country code are required. Maximum 50 marinas.")}</p>
        <button type="button" id="mmTemplate" style="${buttonStyle}">${t("Download CSV Template")}</button>
        <label>${t("CSV file")}<input name="csv" type="file" accept=".csv,text/csv" required style="${inputStyle}"></label>
        <div id="mmPreview" style="color:#AEB6C1;"></div>
        <button type="submit" style="${buttonStyle}background:#0A8EF7;">${t("Import Marinas")}</button>
      </form>`;
    status('');
    $('#mmTemplate').addEventListener('click', () => {
      const url = URL.createObjectURL(new Blob(['name,countryCode,email,phone\r\n'], {type:'text/csv;charset=utf-8'}));
      const link = document.createElement('a');
      link.href = url; link.download = 'marinas-template.csv'; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    let prepared = null;
    $('#mmBulkForm input').addEventListener('change', async event => {
      prepared = null;
      const file = event.target.files[0];
      if (!file) return;
      try {
        if (file.size > 1024 * 1024) throw new Error(tr('CSV file must be smaller than 1 MB.'));
        prepared = parseMarinaCsv(await file.text());
        $('#mmPreview').textContent = tr('marinaImportReady', {count: prepared.length});
        status('');
      } catch (error) { status(error.message, true); $('#mmPreview').textContent = ''; }
    });
    $('#mmBulkForm').addEventListener('submit', event => {
      event.preventDefault();
      if (!prepared) { status('Select a valid CSV file first.', true); return; }
      const rows = prepared;
      run(async () => {
        // Remove submission controls: partial imports must not be submitted twice.
        $('#mmForm').replaceChildren();
        let added = 0, skipped = 0;
        const errors = [];
        const existing = new Set(store.marinas.map(m => `${m.name.trim().toLowerCase()}|${m.countryCode || ''}`));
        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const key = `${row.name.toLowerCase()}|${row.countryCode}`;
          if (existing.has(key)) { skipped++; continue; }
          status(`Importing marina ${i + 1} of ${rows.length}…`);
          try {
            await call('createMarina', {...row, sourceClientId});
            existing.add(key); added++;
          } catch (error) {
            errors.push(`${row.name}: ${error.message || itUI('Creation failed')}`);
            // Stop on access/session/network errors; their outcome may be uncertain.
            if (['functions/unauthenticated', 'functions/permission-denied', 'functions/unavailable', 'functions/deadline-exceeded', 'functions/internal'].includes(error.code) || store.authUser?.uid !== uid) break;
          }
        }
        try {
          store.marinas = (await getMyMarinas(uid, store.userProfile?.userId || 0)).filter(m => Number(m.isActive) === 1);
          renderList();
        } catch (error) { errors.push('Refresh the WebApp to load the updated marina list.'); }
        const notProcessed = rows.length - added - skipped - errors.filter(e => !e.startsWith('Refresh')).length;
        status(`Import complete: ${added} added · ${skipped} skipped · ${errors.filter(e => !e.startsWith('Refresh')).length} failed${notProcessed > 0 ? ` · ${notProcessed} not processed` : ''}.${errors.length ? '\n' + errors.join('\n') : ''}`, errors.length > 0);
      });
    });
  }
  $('#mmJoin').addEventListener('click', () => showForm('join'));
  $('#mmVisibility').onchange = renderList;
  renderList();
  run(loadManaged, lt('Loading marinas…', 'جارٍ تحميل المارينات…'));
}

// RFC-style CSV quoting: supports commas, escaped quotes and line breaks in fields.
export function parseMarinaCsv(text) {
  const rows = [];
  let row = [], field = '', quoted = false, closed = false;
  text = String(text).replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (ch === '"') { quoted = false; closed = true; }
      else field += ch;
    } else if (ch === '"') {
      if (field || closed) throw new Error(tr('Invalid CSV quoting.'));
      quoted = true;
    } else if (ch === ',' || ch === '\n' || ch === '\r') {
      row.push(field); field = ''; closed = false;
      if (ch !== ',') {
        if (row.some(v => v.trim())) rows.push(row);
        row = [];
        if (ch === '\r' && text[i + 1] === '\n') i++;
      }
    } else {
      if (closed && !/\s/.test(ch)) throw new Error(tr('Unexpected text after a quoted CSV field.'));
      if (!closed) field += ch;
    }
  }
  if (quoted) throw new Error(tr('Unclosed quoted CSV field.'));
  row.push(field);
  if (row.some(v => v.trim())) rows.push(row);
  if (rows.length < 2) throw new Error(tr('CSV must contain a header and at least one marina.'));
  const header = rows.shift().map(v => v.trim().toLowerCase());
  if (new Set(header).size !== header.length || !header.includes('name') || !header.includes('countrycode')) {
    throw new Error(tr('CSV requires unique column headers including name and countryCode.'));
  }
  if (rows.length > 50) throw new Error(tr('Import a maximum of 50 marinas at a time.'));
  return rows.map((values, index) => {
    if (values.length !== header.length) throw new Error(`Row ${index + 2}: column count does not match the header.`);
    const get = name => (values[header.indexOf(name)] || '').trim();
    const marina = {name:get('name'), countryCode:get('countrycode').toUpperCase(), email:get('email'), phone:get('phone')};
    if (!marina.name || marina.name.length > 120 || !/^[A-Z]{2}$/.test(marina.countryCode) || marina.email.length > 254 || marina.phone.length > 50) {
      throw new Error(`Row ${index + 2}: check name, country code and contact lengths.`);
    }
    if (marina.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(marina.email)) throw new Error(`Row ${index + 2}: invalid email.`);
    return marina;
  });
}
