import { sheetCloseButton } from '../ui/sheetClose.js';
import { italianUI as itUI } from '../i18n.js';
import { updateMaintenanceTask } from '../util/MaintenanceArchive.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
import { store } from '../store.js';
import { toast } from '../ui/toast.js';
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  setDoc,
  serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
import { db } from '../firebase.js';

const MAINTENANCE_TYPES = [
  'Engine',
  'Electrical',
  'Plumbing',
  'Hull',
  'Deck',
  'Rigging',
  'Navigation',
  'Safety Equipment',
  'HVAC',
  'Fuel System',
  'Steering',
  'Bilge',
  'Interior',
  'Exterior',
  'Other'
];

export async function showAddMaintenanceSheet(opts = {}) {
  const { item, onSaved } = opts;
  const isEdit = !!item;
  const originClientId = Number(store.activeClientId);
  const originUid = store.authUser?.uid;
  const sameSession = () => Number(store.activeClientId) === originClientId
    && store.authUser?.uid === originUid && (!opts.canSave || opts.canSave());
  const source = !isEdit && opts.yardSpaceId
    ? `YARD_STORAGE:${String(opts.yardSpaceLabel || opts.yardSpaceId).slice(0,80)}`
    : 'MANUAL';

  const boat = await resolveActiveBoat(
    isEdit && item ? item.boatId : Number(opts.boatId || 0)
  );

  if (!sameSession()) return;

  if (!boat || !boat.id) {
    toast(tr(opts.boatId ? 'The selected boat is unavailable. Refresh the yard.' : 'Set a boat as active first'), {
      kind: 'error'
    });
    return;
  }

  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'sheet';

  sheet.innerHTML = `
    ${sheetCloseButton()}

 <div class="maintenance-sheet-header"
  style="position:sticky;top:0;z-index:2;flex-shrink:0;display:flex;align-items:center;min-height:48px;background:var(--color-surface, #1C222A);">

  <div class="sheet-title"
    style="flex:1;margin:0;padding:12px 48px;text-align:center;">
    ${isEdit ? tr('Edit Maintenance') : tr('Add Maintenance')}
  </div>

  <button type="button" id="iv-close" aria-label="${tr("Close maintenance sheet")}"
    style="position:absolute;right:0;top:2px;display:grid;place-items:center;width:44px;height:44px;padding:0;border:0;border-radius:8px;background:transparent;color:#F5F7F9;cursor:pointer;">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
      stroke="currentColor" stroke-width="2" stroke-linecap="round"
      aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18"/>
    </svg>
  </button>
</div>

    <form id="amForm"
          class="add-form"
          novalidate>

      <div class="add-scroll">

        <label class="add-label">${tr("Boat")}</label>

        <div class="add-input"
             style="
               padding-top:14px;
               padding-bottom:14px;
               color:var(--color-text-secondary);
             ">
          ${tr("Boat:" )}
          ${escapeHtml(
            boat.name || tr('Unnamed')
          )}
        </div>

        ${!isEdit && opts.yardSpaceId ? `<p class="add-label">${escapeHtml(itUI('Yard Storage · ') + (opts.yardSpaceLabel || opts.yardSpaceId))}</p>` : ''}

        <label class="add-label"
               for="am-type">${tr("Type")}</label>

        <select class="add-input add-select"
                id="am-type">
          ${MAINTENANCE_TYPES.map(type => `
            <option
              value="${escapeAttr(type)}"
              ${
                isEdit &&
                item.type === type
                  ? 'selected'
                  : ''
              }>
              ${escapeHtml(tr(type))}
            </option>
          `).join('')}
        </select>

        <label class="add-label"
               for="am-date">${tr("Date")}</label>

        <input class="add-input"
               id="am-date"
               type="date">

        <label class="add-label"
               for="am-notes">${tr("Notes")}</label>

        <textarea
          class="add-input"
          id="am-notes"
          rows="3"
          placeholder="${tr("Describe the work or issue")}"
        ></textarea>

      </div>

      <button type="submit"
              class="add-save"
              id="am-save">
        ${isEdit
          ? itUI('Update Maintenance')
          : itUI('Add Maintenance')}
      </button>

    </form>
  `;

  document
    .getElementById('modalRoot')
    .append(backdrop, sheet);

  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  let unsubscribeContext = null;
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    unsubscribeContext?.();
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');

    setTimeout(() => {
      backdrop.remove();
      sheet.remove();
    }, 220);
  };

  unsubscribeContext = store.subscribe(() => { if (!sameSession()) close(); });
  if (!sameSession()) { close(); return; }
  backdrop.addEventListener('click', close);
  sheet.querySelector('[data-sheet-close]').addEventListener('click', close);
sheet.querySelector('#iv-close').addEventListener('click', close);

  const today = new Date()
    .toISOString()
    .slice(0, 10);

  if (isEdit) {
    sheet.querySelector('#am-date').value =
      item.date || today;

    sheet.querySelector('#am-notes').value =
      item.notes || '';
  } else {
    sheet.querySelector('#am-date').value =
      today;
  }

  const form =
    sheet.querySelector('#amForm');

  const save =
    sheet.querySelector('#am-save');

  form.addEventListener(
    'submit',
    async event => {
      event.preventDefault();
      if (save.disabled || closed) return;
      if (!sameSession()) { close(); return; }

      const type =
        sheet.querySelector('#am-type').value;

      const date =
        sheet.querySelector('#am-date').value;

      const notes =
        sheet
          .querySelector('#am-notes')
          .value
          .trim();

      if (!type) {
        toast(tr('Select a type'), {
          kind: 'error'
        });
        return;
      }

      if (!date) {
        toast(tr('Select a date'), {
          kind: 'error'
        });
        return;
      }

      save.disabled = true;
      save.textContent = tr('Saving…');

      try {
        if (isEdit) {
          await updateMaintenance(item, {
            type,
            date,
            notes,
            boatId: boat.id
          });
        } else {
          await createMaintenance({
            type,
            date,
            notes,
            boatId: boat.id,
            boatName: boat.name,
            clientId: originClientId,
            source,
            yardSpaceId: opts.yardSpaceId || null
          });
        }

        close();

        toast(
          isEdit
            ? itUI('Maintenance updated')
            : itUI('Maintenance added'),
          { kind: 'success' }
        );

        if (onSaved && sameSession()) {
          await onSaved();
        }
      } catch (error) {
        console.error(
          '[maintenance save] failed',
          error
        );

        save.disabled = false;

        save.textContent = isEdit
          ? tr('Update Maintenance')
          : tr('Add Maintenance');

        let errorElement =
          sheet.querySelector('.add-error');

        if (!errorElement) {
          errorElement =
            document.createElement('div');

          errorElement.className =
            'add-error';

          form.insertBefore(
            errorElement,
            save
          );
        }

        errorElement.textContent =
          error.message ||
          tr('Failed to save.');
      }
    }
  );
  return close;
}

async function resolveActiveBoat(
  preferBoatId
) {
  const clientId =
    Number(store.activeClientId);

  if (!clientId) return null;
  if (store.assignedYacht) return store.assignedYacht.id === preferBoatId ? store.assignedYacht : null;

  try {
    if (preferBoatId) {
      const snapshot = await getDocs(
        query(
          collection(db, 'boats'),
          where(
            'clientId',
            '==',
            clientId
          ),
          where(
            'id',
            '==',
            Number(preferBoatId)
          )
        )
      );

      if (!snapshot.empty) {
        const data =
          snapshot.docs[0].data();

        return {
          id: Number(data.id),
          name: data.name || ''
        };
      }
    }

    if (preferBoatId) return null;

    if (store.activeBoatId) {
      const snapshot = await getDocs(
        query(
          collection(db, 'boats'),
          where(
            'clientId',
            '==',
            clientId
          ),
          where(
            'id',
            '==',
            Number(store.activeBoatId)
          )
        )
      );

      if (!snapshot.empty) {
        const data =
          snapshot.docs[0].data();

        return {
          id: Number(data.id),
          name: data.name || ''
        };
      }
    }

    if (
      store.activeBoat &&
      store.activeBoat.id
    ) {
      return {
        id: Number(
          store.activeBoat.id
        ),
        name:
          store.activeBoat.name || ''
      };
    }

    const snapshot = await getDocs(
      query(
        collection(db, 'boats'),
        where(
          'clientId',
          '==',
          clientId
        ),
        where(
          'isActive',
          '==',
          true
        )
      )
    );

    if (!snapshot.empty) {
      const data =
        snapshot.docs[0].data();

      return {
        id: Number(data.id),
        name: data.name || ''
      };
    }
  } catch (error) {
    console.error(
      '[maintenance form] boat lookup failed',
      error
    );
  }

  return null;
}

async function createMaintenance({
  type,
  date,
  notes,
  boatId,
  boatName,
  clientId,
  source = 'MANUAL',
  yardSpaceId = null
}) {

  if (!clientId) {
    throw new Error(tr('No active client'));
  }

  const now = Date.now();
  const nextId = now;

  const userId = String(
    store.userProfile?.userId || 0
  );

  const cloudId =
    crypto.randomUUID
      ? crypto.randomUUID()
      : `${clientId}_${nextId}`;

  await setDoc(
    doc(db, 'maintenance', cloudId),
    {
      id: nextId,
      cloudId,
      clientId,
      boatId: Number(boatId),
      berthId: null,
      assetId: null,
      type,
      date,
      notes: notes || '',
      completed: false,
      status: 'ACTIVE',
      source,
      ...(yardSpaceId ? {yardSpaceId: String(yardSpaceId)} : {}),
      priority: null,
      assignedTo: null,
      assignedBy: null,
      assignedAt: 0,
      deferReason: null,
      riskLevel: null,
      mitigation: null,
      reviewDate: null,
      deferredBy: null,
      deferredAt: 0,
      reviewStatus: null,
      lastModified: now,
      lastModifiedBy: userId,
      syncTime: serverTimestamp(),
      syncedAt: 0
    }
  );

  return nextId;
}

async function updateMaintenance(
  item,
  {
    type,
    date,
    notes,
    boatId
  }
) {
  const now = Date.now();

  const userId = String(
    store.userProfile?.userId || 0
  );

  await updateMaintenanceTask(
    doc(
      db,
      'maintenance',
      String(item._docId)
    ),
    {
      type,
      date,
      notes: notes || '',
      boatId: Number(boatId),
      lastModified: now,
      lastModifiedBy: userId
    }
  );
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(
      /[&<>"']/g,
      character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[character])
    );
}

function escapeAttr(value) {
  return String(value ?? '')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}