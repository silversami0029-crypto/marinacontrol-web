import { italianUI as itUI } from '../i18n.js';
import {showYardJobCosts} from './YardJobCosts.js';
import {packageManagers} from '../util/YardWorkPackageApi.js';
import {showMaintenanceLaunchReview} from './MaintenanceLaunchReviewSheet.js';
import { setMaintenanceArchived, deleteMaintenanceTask } from '../util/MaintenanceArchive.js';
import { isMaintenanceCompleted } from '../util/MaintenanceState.js';
import { showMaintenanceDetail } from './MaintenanceDetailSheet.js';
import { updateMaintenanceTask } from '../util/MaintenanceArchive.js';
import { t } from '../i18n.js';
// js/screens/MaintenanceMenuSheet.js
import { store } from '../store.js';
import { toast } from '../ui/toast.js';
import { confirmSheet } from '../ui/confirm.js';
import { showAssignOwnerSheet } from './AssignOwnerSheet.js';
import { showDeferMaintenanceSheet } from './DeferMaintenanceSheet.js';
import { showAddMaintenanceSheet } from './AddMaintenanceSheet.js';
import { showReviewMaintenanceSheet } from './ReviewMaintenanceSheet.js';
import { doc } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
import { db } from '../firebase.js';

export function showMaintenanceMenu(item, { onChanged } = {}) {
  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'sheet';

  const status = (item.status || 'ACTIVE').toUpperCase();
  const isCompleted = isMaintenanceCompleted(item);
  const isDeferred = status === 'DEFERRED';

  sheet.innerHTML = `
 
   
<div class="invoice-sheet-header"
  style="position:sticky;top:0;z-index:2;flex-shrink:0;display:flex;align-items:center;min-height:48px;background:var(--color-surface, #1C222A);">

 <div class="sheet-title" style="width:100%;box-sizing:border-box;padding:0 48px;text-align:center;">${escapeHtml(item.type || t('Maintenance'))}

</div>

  <button type="button" id="iv-close" aria-label="${itUI("Close invoice sheet")}"
    style="position:absolute;right:0;top:2px;display:grid;place-items:center;width:44px;height:44px;padding:0;border:0;border-radius:8px;background:transparent;color:#F5F7F9;cursor:pointer;">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
      stroke="currentColor" stroke-width="2" stroke-linecap="round"
      aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18"/>
    </svg>
  </button>
</div>

    ${isDeferred ? `
      <div class="sheet-item" id="mmReview">
        <div class="sheet-item-icon">
          <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="1.8"
               stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2"/>
            <line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8" y1="2" x2="8" y2="6"/>
            <line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
        </div>
        <div class="sheet-item-text">
          <div class="sheet-item-title">${t("Review Due")}</div>
          <div class="sheet-item-subtitle">${t("Complete, extend, or escalate")}</div>
        </div>
      </div>
      <div class="sheet-gap-8"></div>
    ` : ''}

    ${!isCompleted ? `
      <div class="sheet-item" id="mmComplete">
        <div class="sheet-item-icon">
          <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="1.8"
               stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="9"/>
            <polyline points="8 12 11 15 16 9"/>
          </svg>
        </div>
        <div class="sheet-item-text">
          <div class="sheet-item-title">${t("Complete")}</div>
          <div class="sheet-item-subtitle">${t("Mark this task as done")}</div>
        </div>
      </div>
      <div class="sheet-gap-8"></div>
    ` : ''}

    <div class="sheet-item" id="mmDefer">
      <div class="sheet-item-icon">
        <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 2h12v6l-6 4 6 4v6H6v-6l6-4-6-4z"/>
        </svg>
      </div>
      <div class="sheet-item-text">
        <div class="sheet-item-title">${t(isDeferred ? itUI('Update Defer') : itUI('Defer'))}</div>
        <div class="sheet-item-subtitle">${t(isDeferred ? itUI('Change reason, risk, or date') : itUI('Postpone with a review date'))}</div>
      </div>
    </div>
    <div class="sheet-gap-8"></div>

    <div class="sheet-item" id="mmEdit">
      <div class="sheet-item-icon">
        <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 20h9"/>
          <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>
        </svg>
      </div>
      <div class="sheet-item-text">
        <div class="sheet-item-title">${t("Edit")}</div>
        <div class="sheet-item-subtitle">${t("Change type, date, or notes")}</div>
      </div>
    </div>
    <div class="sheet-gap-8"></div>

    <div class="sheet-item" id="mmAssignOwner">
      <div class="sheet-item-icon">
        <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
          <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
        </svg>
      </div>
      <div class="sheet-item-text">
        <div class="sheet-item-title">${t("Assign Owner")}</div>
        <div class="sheet-item-subtitle">${t("Assign this task to a crew member")}</div>
      </div>
    </div>
    <div class="sheet-gap-8"></div>

    <div class="sheet-item sheet-item--danger" id="mmDelete">
      <div class="sheet-item-icon">
        <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 6h18"/>
          <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
          <path d="M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/>
        </svg>
      </div>
      <div class="sheet-item-text">
        <div class="sheet-item-title">${t("Delete")}</div>
        <div class="sheet-item-subtitle">${t("Remove this task permanently")}</div>
      </div>
    </div>
  `;

  // Completed work is archived rather than deleted; archived records are read-only.
  if (isCompleted || item.archived === true) {
    for (const id of ['mmReview', 'mmComplete', 'mmDefer', 'mmEdit', 'mmAssignOwner', 'mmDelete']) {
      const row = sheet.querySelector('#' + id);
      if (row?.nextElementSibling?.classList.contains('sheet-gap-8')) row.nextElementSibling.remove();
      row?.remove();
    }
  }
  const extra = document.createElement('div');
  extra.innerHTML = `
    <button type="button" class="sheet-item maintenance-menu-action" id="mmView">
      <div class="sheet-item-icon">ⓘ</div>
      <div class="sheet-item-text"><div class="sheet-item-title">${t('View')}</div></div>
    </button>
    ${isCompleted || item.archived === true ? `
      <button type="button" class="sheet-item maintenance-menu-action maintenance-archived" id="mmArchive">
        <div class="sheet-item-icon"><svg class="sheet-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 8h16v13H4zM3 3h18v5H3zM9 12h6"/></svg></div>
        <div class="sheet-item-text"><div class="sheet-item-title">${t(item.archived === true ? itUI('Restore') : itUI('Archive'))}</div></div>
      </button>` : ''}
  `;
  if(packageManagers()&&Number(item.boatId)>0&&!isCompleted&&item.archived!==true){
    const review=document.createElement('button');review.type='button';review.className='sheet-item maintenance-menu-action';review.id='mmLaunchRequirement';
    review.innerHTML=`<div class="sheet-item-icon">⚑</div><div class="sheet-item-text"><div class="sheet-item-title">${itUI("Launch requirement")}</div><div class="sheet-item-subtitle">${itUI("Review required or optional work")}</div></div>`;extra.append(review);
  }
  if(item.workPackageId&&Number(item.boatId)>0){
    const costs=document.createElement('button');costs.type='button';costs.className='sheet-item maintenance-menu-action';costs.id='mmLogWork';
    costs.innerHTML='<div class="sheet-item-icon"><svg class="sheet-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></div><div class="sheet-item-text"><div class="sheet-item-title">'+(item.archived===true?itUI('Job costs'):itUI('Log work'))+`</div><div class="sheet-item-subtitle">${itUI("Hours, materials and package costs")}</div></div>`;extra.append(costs);
  }
  sheet.append(extra);

  document.getElementById('modalRoot').append(backdrop, sheet);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  const close = () => {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); sheet.remove(); }, 220);
  };

  sheet.querySelector('#mmLogWork')?.addEventListener('click',()=>{close();setTimeout(()=>{if(Number(store.activeClientId)===Number(item.clientId))showYardJobCosts({packageId:item.workPackageId,taskDocId:item._docId});},250);});
  sheet.querySelector('#mmLaunchRequirement')?.addEventListener('click',()=>{close();setTimeout(()=>showMaintenanceLaunchReview(item,{onChanged}),250);});
  sheet.querySelector('#mmView').addEventListener('click', () => {
    close();
    setTimeout(() => showMaintenanceDetail(item), 250);
  });
  sheet.querySelector('#mmArchive')?.addEventListener('click', async () => {
    close();
    await archiveItem(item, onChanged);
  });

  backdrop.addEventListener('click', close);
sheet.querySelector('#iv-close').addEventListener('click', close);

  sheet.querySelector('#mmReview')?.addEventListener('click', () => {
    close();
    setTimeout(() => showReviewMaintenanceSheet(item, { onChanged }), 250);
  });

  sheet.querySelector('#mmComplete')?.addEventListener('click', async () => {
    close();
    await completeItem(item, onChanged);
  });

  sheet.querySelector('#mmDefer')?.addEventListener('click', () => {
    close();
    setTimeout(() => showDeferMaintenanceSheet(item, { onChanged }), 250);
  });

  sheet.querySelector('#mmEdit')?.addEventListener('click', () => {
    close();
    setTimeout(() => showAddMaintenanceSheet({ item, onSaved: onChanged }), 250);
  });

  sheet.querySelector('#mmAssignOwner')?.addEventListener('click', () => {
    close();
    setTimeout(() => showAssignOwnerSheet(item, { onChanged }), 250);
  });

  sheet.querySelector('#mmDelete')?.addEventListener('click', async () => {
    close();
    await deleteItem(item, onChanged);
  });
}

async function archiveItem(item, onChanged) {
  const archived = item.archived !== true;
  const ok = await confirmSheet({
    action: archived ? 'archive' : 'restore',
    title: t(archived ? 'Archive maintenance task?' : 'Restore maintenance task?'),
    message: t(archived
      ? 'This task will move to Archived. Its completion, history and linked records will be kept.'
      : 'This task will return to Current. It will remain completed and its history will be kept.'),
    confirmText: t(archived ? 'Archive' : 'Restore'),
    cancelText: t('Cancel')
  });
  if (!ok) return;
  try {
    await setMaintenanceArchived(item, archived);
    toast(t(archived ? 'Task archived' : 'Task restored'), { kind: 'success' });
    onChanged?.();
  } catch (error) {
    toast(error.message || t('Could not update archive state'), { kind: 'error' });
  }
}

async function completeItem(item, onChanged) {
  try {
    const now = Date.now();
    const userId = String(store.userProfile?.userId || 0);

    await updateMaintenanceTask(doc(db, 'maintenance', String(item._docId)), {
      completed: true,
      status: 'COMPLETED',
      lastModified: now,
      lastModifiedBy: userId
    });

    toast(t('completeNamed', {name:item.type}), { kind: 'success' });
    if (onChanged) onChanged();
  } catch (err) {
    console.error('[maintenance] complete failed', err);
    toast(t('Failed to mark complete'), { kind: 'error' });
  }
}

async function deleteItem(item, onChanged) {
  const ok = await confirmSheet({
    title: t('Delete maintenance task?'),
    message: t('removeNamedIrreversible', {name:item.type}),
    confirmText: t('Delete'),
    cancelText: t('Cancel')
  });
  if (!ok) return;

  try {
    await deleteMaintenanceTask(item);
    toast(t('deletedNamed', {name:item.type}), { kind: 'success' });
    if (onChanged) onChanged();
  } catch (err) {
    console.error('[maintenance] delete failed', err);
    toast(t('Failed to delete'), { kind: 'error' });
  }
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}