import { italianUI as itUI } from '../i18n.js';
import {readYardWorkPackages,maintenanceScope,launchLabel} from '../util/YardWorkPackageApi.js';
import { maintenanceColours, maintenanceVisible, isFleetOpenMaintenance } from '../util/MaintenanceState.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
// js/screens/MaintenanceScreen.js
import { store } from '../store.js';
import { toast } from '../ui/toast.js';
import { showMaintenanceMenu } from './MaintenanceMenuSheet.js';
import { showMaintenanceHelp } from './MaintenanceHelp.js';
import { showMaintenanceDetail } from './MaintenanceDetailSheet.js';
import {
  collection, query, where, onSnapshot, getDocs
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
import { db } from '../firebase.js';

let unsubscribe = null;
let launchLoadToken=0;
let currentBoatId = 0;
let currentBoatName = '';
let currentItems = [];
let isSearchOpen = false;
let attentionFilter = false;
let visibility = 'current';

export function mountMaintenanceScreen() {
  launchLoadToken++;
  const screen = document.getElementById('screen');

  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  const urlBoatId = Number(params.get('boatId') || 0);
  attentionFilter = (params.get('filter') || '').toLowerCase() === 'attention';

  if (unsubscribe) { unsubscribe(); unsubscribe = null; }
  currentItems = [];
  visibility = 'current';
  isSearchOpen = false;

  screen.innerHTML = `
    <div class="mt-header" id="mtHeader">
      <div class="mt-header-row">
        <button class="mt-icon-btn" id="mtBack" aria-label="${tr("Back")}">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
               stroke="currentColor" stroke-width="2"
               stroke-linecap="round" stroke-linejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div class="mt-pill" id="mtPill">${tr("Maintenance")}</div>
        <button class="mt-icon-btn" id="mtHelp" aria-label="${tr("Help")}">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
               stroke="currentColor" stroke-width="1.8"
               stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="9"/>
            <line x1="12" y1="11" x2="12" y2="16"/>
            <circle cx="12" cy="7.5" r="0.8" fill="currentColor"/>
          </svg>
        </button>
        <div class="mt-header-spacer"></div>
        <button class="mt-icon-btn" id="mtSearchToggle" aria-label="${tr("Search")}">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
               stroke="currentColor" stroke-width="1.8"
               stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="7"/>
            <line x1="16.5" y1="16.5" x2="21" y2="21"/>
          </svg>
        </button>
      </div>
    </div>

    <div class="boats-search-bar" id="mtSearchBar" hidden>
      <input id="mtSearchInput" type="text" placeholder="${tr("Search maintenance...")}" autocomplete="off">
      <button type="button" class="search-cancel" id="mtSearchCancel">${tr("Cancel")}</button>
    </div>

    <div class="mt-visibility">
      <label for="mtVisibility">${tr('Task visibility')}</label>
      <select id="mtVisibility">
        <option value="current">${tr('Current')}</option>
        <option value="archived">${tr('Archived')}</option>
        <option value="all">${tr('All')}</option>
      </select>
    </div>

    <div class="mt-list" id="mtList">
      <div class="boats-loading"><div class="spinner-ring"></div></div>
    </div>

    <button class="cm-fab" id="mtFabAdd" aria-label="${tr("Add maintenance")}">
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
           stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
        <line x1="12" y1="5" x2="12" y2="19"/>
        <line x1="5" y1="12" x2="19" y2="12"/>
      </svg>
    </button>
  `;



 document.getElementById('mtBack')?.addEventListener('click', () => {
   if (store.assignedYacht) location.hash = '#/my-yacht';
   else history.back();
 });

    document.getElementById('mtHelp').addEventListener('click', showMaintenanceHelp);

  document.getElementById('mtSearchToggle').addEventListener('click', () => {
    isSearchOpen = true;
    document.getElementById('mtHeader').hidden = true;
    document.getElementById('mtSearchBar').hidden = false;
    document.getElementById('mtSearchInput').focus();
  });

  document.getElementById('mtSearchCancel').addEventListener('click', () => {
    isSearchOpen = false;
    document.getElementById('mtSearchBar').hidden = true;
    document.getElementById('mtHeader').hidden = false;
    document.getElementById('mtSearchInput').value = '';
    renderList();
  });

  document.getElementById('mtSearchInput').addEventListener('input', renderList);

  document.getElementById('mtFabAdd').addEventListener('click', async () => {
    try {
      const m = await import('./AddMaintenanceSheet.js');
      await m.showAddMaintenanceSheet(store.assignedYacht ? { boatId: store.assignedYacht.id } : {});
    } catch (err) {
      console.error('[maintenance fab] failed', err);
      toast(tr('Could not open Add Maintenance'));
    }
  });

  document.getElementById('mtVisibility').addEventListener('change', event => {
    visibility = event.target.value;
    renderList();
  });

  const fleetScope = params.get('scope');
  if (['fleet', 'fleet-open'].includes(fleetScope) && !urlBoatId && Number(store.activeClientId) > 0) {
    currentBoatId = 0;
    currentBoatName = '';
    const openOnly = fleetScope === 'fleet-open';
    document.getElementById('mtPill').textContent = tr(openOnly ? 'Open maintenance' : 'Fleet maintenance');
    document.getElementById('mtVisibility').closest('.mt-visibility').hidden = openOnly;
    subscribeToMaintenance(Number(store.activeClientId), 0, openOnly);
  } else {
    resolveBoatAndSubscribe(urlBoatId);
  }
}

/* ============================================================
   RESOLVE BOAT → SUBSCRIBE
   ============================================================ */
async function resolveBoatAndSubscribe(urlBoatId) {
  const clientId = Number(store.activeClientId);
  if (!clientId) {
    document.getElementById('mtList').innerHTML =
      `<div class="boats-empty"><h2>${tr("No client assigned")}</h2></div>`;
    return;
  }

  const yacht = store.assignedYacht;
  let boatId = yacht?.id || urlBoatId;

  if (yacht) {
    currentBoatName = yacht.name || '';
  } else {
    try {
      if (!boatId) {
        const snap = await getDocs(
          query(
            collection(db, 'boats'),
            where('clientId', '==', clientId),
            where('isActive', '==', true)
          )
        );
        if (!snap.empty) {
          const docSnap = snap.docs[0];
          const data = docSnap.data();
          boatId = Number(data.id || docSnap.id);
          currentBoatName = data.name || '';
        }
      } else {
        const boatSnap = await getDocs(
          query(
            collection(db, 'boats'),
            where('clientId', '==', clientId),
            where('id', '==', boatId)
          )
        );
        if (!boatSnap.empty) {
          currentBoatName = boatSnap.docs[0].data().name || '';
        }
      }
    } catch (err) {
      console.error('[maintenance] boat lookup failed', err);
    }
  }

  if (!boatId) {
    document.getElementById('mtList').innerHTML =
      `<div class="boats-empty">
         <h2>${tr("No active boat")}</h2>
         <p>${tr("Set a boat as active to see its maintenance.")}</p>
       </div>`;
    return;
  }

  currentBoatId = boatId;

  const pillText = attentionFilter
    ? `${tr('Attention')} · ${currentBoatName || tr('Maintenance')}`
    : (currentBoatName ? `${tr('Maintenance')} · ${currentBoatName}` : tr('Maintenance'));

  document.getElementById('mtPill').textContent = pillText;

  subscribeToMaintenance(clientId, boatId);
}

function subscribeToMaintenance(clientId, boatId, fleetOpen = false) {
  const q = query(
    collection(db, 'maintenance'),
    where('clientId', '==', Number(clientId)),
    ...(store.assignedYacht ? [where('boatId', '==', store.assignedYacht.id)] : [])
  );

  unsubscribe = onSnapshot(q, (snap) => {
    currentItems = snap.docs
      .map(d => {
        const data = d.data();
        return {
          id: data.id != null ? Number(data.id) : Number(d.id),
          _docId: d.id,
          clientId: Number(data.clientId || 0),
          boatId: data.boatId != null ? Number(data.boatId) : null,
          berthId: data.berthId != null ? Number(data.berthId) : null,
          type: data.type || '',
          date: data.date || '',
          status: data.status || (data.completed ? 'COMPLETED' : 'ACTIVE'),
          archived: data.archived === true,
          archivedAt: Number(data.archivedAt || 0),
          archivedBy: data.archivedBy || '',
          archiveModifiedAt: Number(data.archiveModifiedAt || 0),
          archiveModifiedBy: data.archiveModifiedBy || '',
          priority: data.priority || '',
          completed: !!data.completed,
          notes: data.notes || '',
          source: data.source || '',
          workPackageId:data.workPackageId||'',workPackageName:data.workPackageName||'',requiredBeforeLaunch:data.requiredBeforeLaunch,
          workPackageTaskTitle:data.workPackageTaskTitle||'',
          assignedTo: data.assignedTo || '',
          assignedBy: data.assignedBy || '',
          assignedAt: Number(data.assignedAt || 0),
          deferReason: data.deferReason || '',
          riskLevel: data.riskLevel || '',
          mitigation: data.mitigation || '',
          reviewDate: data.reviewDate || '',
          deferredBy: data.deferredBy || '',
          deferredAt: Number(data.deferredAt || 0),
          lastModified: Number(data.lastModified || 0)
        };
      })
      .filter(item => {
        if (fleetOpen) return isFleetOpenMaintenance(item);
        // A zero boat ID denotes the marina-wide fleet view; tenant access stays in the query.
        if (!boatId) return true;
        const belongsToBoat = item.boatId && Number(item.boatId) === Number(boatId);
        if (!belongsToBoat) return false;

        if (!attentionFilter) return true;

        if (item.completed || item.status === 'COMPLETED') return false;
        if (item.status === 'ESCALATED') return true;

        if (!item.date) return false;
        const due = new Date(item.date + 'T00:00:00').getTime();
        if (isNaN(due)) return false;

        const now = Date.now();
        return due < now || (due - now) <= 7 * 24 * 60 * 60 * 1000;
      });

    renderList();
    if (store.assignedYacht || !boatId) return;
    const launchToken=++launchLoadToken;
    readYardWorkPackages(boatId).then(data=>{
      if(launchToken!==launchLoadToken||Number(store.activeClientId)!==Number(clientId)||!document.getElementById('mtList'))return;
      const checked=new Map(data.tasks.map(t=>[t._docId,t]));
      currentItems=currentItems.map(item=>{const server=checked.get(item._docId);return server&&server.launchScope===maintenanceScope(item)?{...item,launchScope:server.launchScope,launchState:server.launchState}:item;});renderList();
    }).catch(err=>console.warn('[maintenance launch review] unavailable',err.message));
  }, (err) => {
    console.error('[maintenance] listen failed', err);
    const listEl = document.getElementById('mtList');
    if (!listEl) return;
    listEl.innerHTML = `
      <div class="boats-empty">
        <h2>${tr("Couldn't load maintenance")}</h2>
        <p>${escapeHtml(err.message || itUI('Permission denied.'))}</p>
      </div>
    `;
  });
}

/* ============================================================
   LIST
   ============================================================ */
function getVisibleItems() {
  const q = (document.getElementById('mtSearchInput')?.value || '').trim().toLowerCase();
  const visible = currentItems.filter(item => maintenanceVisible(item, visibility));
  if (!q) return visible;
  return visible.filter(m =>
    (m.type || '').toLowerCase().includes(q) ||
    (m.notes || '').toLowerCase().includes(q) ||
    (m.status || '').toLowerCase().includes(q) ||
    (m.priority || '').toLowerCase().includes(q) ||
    (m.assignedTo || '').toLowerCase().includes(q) ||
    (m.source || '').toLowerCase().includes(q)
  );
}

function renderList() {
  const listEl = document.getElementById('mtList');
  if (!listEl) return;

  const items = getVisibleItems();

  if (!items.length) {
    const q = (document.getElementById('mtSearchInput')?.value || '').trim();
    let emptyHTML;
    if (q) {
      emptyHTML = `<div class="boats-empty"><h2>${tr("No matches")}</h2><p>${itUI("No maintenance matches \"")}${escapeHtml(q)}"</p></div>`;
    } else if (visibility === 'archived') {
      emptyHTML = `<div class="boats-empty"><h2>${tr('No archived maintenance')}</h2></div>`;
    } else if (attentionFilter) {
      emptyHTML = `<div class="boats-empty"><h2>${tr("All clear")}</h2><p>${tr("No items need attention.")}</p></div>`;
    } else {
      emptyHTML = `<div class="boats-empty"><h2>${tr("No maintenance")}</h2><p>${tr("Tap + to add a task.")}</p></div>`;
    }
    listEl.innerHTML = emptyHTML;
    return;
  }

  const sorted = [...items].sort((a, b) => {
    const order = { ACTIVE: 0, ESCALATED: 1, DEFERRED: 2, COMPLETED: 3 };
    const ao = order[a.status] ?? 4;
    const bo = order[b.status] ?? 4;
    if (ao !== bo) return ao - bo;
    return (b.date || '').localeCompare(a.date || '');
  });

  listEl.innerHTML = sorted.map(m => {
    const state = getRowState(m);
    const isChecklist = (m.source || '').startsWith('CHECKLIST:');
    const isYard = (m.source || '').startsWith('YARD_STORAGE:');

    return `
      <div class="mt-row" data-maint-id="${m.id}">
        <div class="mt-indicator" style="background:${state.color};">
          <span class="mt-indicator-icon">${state.icon}</span>
        </div>

        <div class="mt-info">
          <div class="mt-title">${escapeHtml(m.type || itUI('Maintenance'))}</div>
          ${m.archived ? `<div class="mt-assigned maintenance-archived">${tr('Archived')}</div>` : ''}
          ${m.workPackageName?`<div class="mt-assigned">${itUI("Work package:")} ${escapeHtml(m.workPackageName)}</div>`:''}
          <div class="mt-assigned">${escapeHtml(launchLabel(m))}</div>
          ${m.notes ? `<div class="mt-notes">${escapeHtml(m.notes)}</div>` : ''}
          ${m.assignedTo ? `<div class="mt-assigned">${tr("Assigned:" )} ${escapeHtml(m.assignedTo)}</div>` : ''}
          ${m.source ? `
            <span class="mt-source-badge ${isChecklist ? 'mt-source-checklist' : 'mt-source-manual'}">
              ${isYard ? escapeHtml(itUI('Yard Storage · ') + m.source.slice('YARD_STORAGE:'.length)) : isChecklist ? '📝 Checklist' : '🔧 Manual'}
            </span>
          ` : ''}
          <div class="mt-date" style="color:${state.dateColor};">
            ${escapeHtml(tr(state.dateLabel))}
          </div>
        </div>

        <button class="mt-kebab" data-maint-menu="${m.id}" aria-label="${tr("Menu")}">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
               stroke="currentColor" stroke-width="2"
               stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="5" r="0.6" fill="currentColor"/>
            <circle cx="12" cy="12" r="0.6" fill="currentColor"/>
            <circle cx="12" cy="19" r="0.6" fill="currentColor"/>
          </svg>
        </button>
        <div class="mt-row-divider"></div>
      </div>
    `;
  }).join('');

  listEl.querySelectorAll('.mt-row').forEach(row => {
    const id = Number(row.dataset.maintId);
    const item = sorted.find(m => m.id === id);
    if (!item) return;

    row.addEventListener('click', (e) => {
      if (e.target.closest('[data-maint-menu]')) return;
      showMaintenanceDetail(item);
    });
  });

  listEl.querySelectorAll('[data-maint-menu]').forEach(btn => {
    const id = Number(btn.dataset.maintMenu);
    const item = sorted.find(m => m.id === id);
    if (!item) return;

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      showMaintenanceMenu(item);
    });
  });
}

/* ============================================================
   ROW STATE
   ============================================================ */
function getRowState(m) {
  const now = Date.now();

  if (m.status === 'ESCALATED') {
    return { color: maintenanceColours.escalated, icon: '↑', dateLabel: 'Escalated', dateColor: maintenanceColours.escalated };
  }
  if (m.status === 'DEFERRED') {
    return { color: maintenanceColours.deferred, icon: '⏳', dateLabel: 'Deferred', dateColor: maintenanceColours.deferred };
  }
  if (m.completed || m.status === 'COMPLETED') {
    return { color: maintenanceColours.completed, icon: '✓', dateLabel: 'Completed', dateColor: maintenanceColours.completed };
  }

  if (!m.date) {
    return { color: '#737D89', icon: '•', dateLabel: 'No date', dateColor: '#737D89' };
  }

  const due = new Date(m.date + 'T00:00:00').getTime();
  if (isNaN(due)) {
    return { color: '#737D89', icon: '•', dateLabel: m.date, dateColor: '#737D89' };
  }

  const diffDays = Math.floor((due - now) / (24 * 60 * 60 * 1000));

  if (due < now) {
    const abs = Math.abs(diffDays);
    return {
      color: maintenanceColours.overdue,
      icon: '!',
      dateLabel: `Overdue by ${abs} ${abs === 1 ? 'day' : itUI('days')}`,
      dateColor: maintenanceColours.overdue
    };
  }
  if (diffDays === 0) {
    return { color: maintenanceColours.dueSoon, icon: '⏰', dateLabel: 'Due Today', dateColor: maintenanceColours.dueSoon };
  }
  if (diffDays === 1) {
    return { color: maintenanceColours.dueSoon, icon: '⏰', dateLabel: 'Due Tomorrow', dateColor: maintenanceColours.dueSoon };
  }
  if (diffDays <= 7) {
    return { color: maintenanceColours.dueSoon, icon: '⏰', dateLabel: `Due in ${diffDays} days`, dateColor: maintenanceColours.dueSoon };
  }

  const d = new Date(m.date + 'T00:00:00');
  const label = d.toLocaleDateString(uiLocale(), {
    day: '2-digit', month: 'short', year: 'numeric'
  });
  return { color: '#3DD68C', icon: '', dateLabel: label, dateColor: '#AEB6C1' };
}

/* ============================================================
   HELPERS
   ============================================================ */
function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
export function unmountMaintenanceScreen() {
  unsubscribe?.();
  unsubscribe = null;
  launchLoadToken++;
}
