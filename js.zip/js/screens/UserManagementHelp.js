import { italianUI as itUI } from '../i18n.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
// js/screens/UserManagementHelp.js

export function showUserManagementHelp() {
  const backdrop = document.createElement('div');
  backdrop.className = 'help-backdrop';

  const dialog = document.createElement('div');
  dialog.className = 'help-dialog';

  dialog.innerHTML = `
    <div class="help-scroll">
      <div class="help-pill">${tr("User Management")}</div>

      <p class="help-desc">${tr("Manage the people who can access your marina account and control the role assigned to each user.")}</p>

      <div class="help-section-title">${tr("How to manage users")}</div>

      ${step('1', itUI('Add users'), itUI('Add users using the + Add User button. Enter their name, email, password and required role.'))}
      ${step('2', itUI('Change role'), itUI('Tap an existing user to change their role and adjust their level of access.'))}
      ${step('3', itUI('Remove'), itUI('Swipe a user left or right to remove them. You cannot delete your own account.'))}
      ${step('4', itUI('Invite code'), itUI('Use the Marina Invite Code when authorised users need to join the correct marina account. Tap Copy Code to copy it.'))}

      <div class="help-divider"></div>

      <div class="help-section-title">${tr("User Roles")}</div>
      <div class="help-tips">• <b>${tr("Admin")}</b>${tr("— Full administrative access and user management. •")}<b>${tr("Manager")}</b>${tr("— Management-level operational access. •")}<b>${tr("Staff")}</b>${tr("— Day-to-day marina operational access. •")}<b>${tr("Inspector")}</b>${tr("— Intended for inspection-related work. •")}<b>${tr("Viewer")}</b>${tr("— Read-focused access.")}</div>

      <div class="help-note">
        <b>${tr("Important:")}</b>${tr("User Management is restricted to administrators. Only give access and invite codes to authorised marina personnel.")}</div>

      <div class="help-footer">${tr("Need help? support@marinacontrol.co.uk")}</div>
    </div>

    <div class="help-actions">
      <button type="button" class="help-gotit" id="userMgmtHelpGotIt">${tr("Got it")}</button>
    </div>
  `;

  document.getElementById('modalRoot').append(backdrop, dialog);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    dialog.classList.add('is-open');
  });

  const close = () => {
    backdrop.classList.remove('is-open');
    dialog.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); dialog.remove(); }, 220);
  };

  backdrop.addEventListener('click', close);
  dialog.querySelector('#userMgmtHelpGotIt').addEventListener('click', close);
}

function step(num, title, body) {
  return `
    <div class="help-step">
      <div class="help-step-num">${num}</div>
      <div class="help-step-text"><b>${title}</b> — ${body}</div>
    </div>
  `;
}