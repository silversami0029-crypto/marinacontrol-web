import { sheetCloseButton } from '../ui/sheetClose.js';
import { italianUI as itUI } from '../i18n.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
// js/screens/AddCrewSheet.js
import { store } from '../store.js';
import { toast } from '../ui/toast.js';
import { createCrewMember } from '../db.js';
import { collection, query, where, getDocs } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
import { db } from '../firebase.js';

export function showAddCrewChooser() {
  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'sheet';

  sheet.innerHTML = `
    
<div class="crew-sheet-header"
  style="position:sticky;top:0;z-index:2;flex-shrink:0;display:flex;align-items:center;min-height:48px;background:var(--color-surface, #1C222A);">

  <div class="sheet-title"
    style="flex:1;margin:0;padding:12px 48px;text-align:center;">
    ${tr("Add Crew")}
  </div>

  <button type="button" id="cr-close" aria-label="${itUI("Close Crew sheet")}"
    style="position:absolute;right:0;top:50%;transform:translateY(-50%);display:grid;place-items:center;width:44px;height:44px;padding:0;border:0;border-radius:8px;background:transparent;color:#F5F7F9;cursor:pointer;">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none"
      stroke="currentColor" stroke-width="2" stroke-linecap="round"
      aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18"/>
    </svg>
  </button>
</div>

    <div class="sheet-gap-8"></div>

    <div class="sheet-item" id="acsAddSingle">
      <div class="sheet-item-icon">
        <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round">
          <line x1="12" y1="5" x2="12" y2="19"/>
          <line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
      </div>
      <div class="sheet-item-text">
        <div class="sheet-item-title">${tr("Add Single Crew")}</div>
        <div class="sheet-item-subtitle">${tr("Add one crew member with all details")}</div>
      </div>
      <div class="sheet-chevron">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
             stroke="currentColor" stroke-width="2"
             stroke-linecap="round" stroke-linejoin="round">
          <polyline points="9 6 15 12 9 18"/>
        </svg>
      </div>
    </div>

    <div class="sheet-gap-8"></div>

    <div class="sheet-item" id="acsBulkImport">
      <div class="sheet-item-icon">
        <svg class="sheet-icon" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.8"
             stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
          <polyline points="17 8 12 3 7 8"/>
          <line x1="12" y1="3" x2="12" y2="15"/>
        </svg>
      </div>
      <div class="sheet-item-text">
        <div class="sheet-item-title">${tr("Bulk Import")}</div>
        <div class="sheet-item-subtitle">${tr("Import multiple crew from CSV")}</div>
      </div>
      <div class="sheet-chevron">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
             stroke="currentColor" stroke-width="2"
             stroke-linecap="round" stroke-linejoin="round">
          <polyline points="9 6 15 12 9 18"/>
        </svg>
      </div>
    </div>
  `;

  document.getElementById('modalRoot').append(backdrop, sheet);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  const close = () => {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); sheet.remove(); }, 220);
  };

  backdrop.addEventListener('click', close);
sheet.querySelector('#cr-close').addEventListener('click', close);

  sheet.querySelector('#acsAddSingle').addEventListener('click', () => {
    close();
    setTimeout(showAddCrewForm, 250);
  });

  sheet.querySelector('#acsBulkImport').addEventListener('click', () => {
    close();
    setTimeout(() => {
      import('./ImportCrewSheet.js').then(m => m.showImportCrewSheet());
    }, 250);
  });
}

function showAddCrewForm() {
  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'sheet';

  sheet.innerHTML = `
    ${sheetCloseButton()}
    <div class="sheet-title" style="text-align:center;">${tr("Add Crew")}</div>

    <form id="acsForm" class="add-form" novalidate autocomplete="off">
      <input type="text"     name="fakeusernameremembered" style="display:none" tabindex="-1" autocomplete="username">
      <input type="password" name="fakepasswordremembered"  style="display:none" tabindex="-1" autocomplete="current-password">

      <div class="add-scroll">
        <label class="add-label" for="acs-name">${tr("Full Name")}</label>
        <input class="add-input" id="acs-name" name="acs-name"
               type="text" placeholder="${tr("Full Name")}"
               autocomplete="off" autocorrect="off" autocapitalize="words" spellcheck="false">

        <label class="add-label" for="acs-email">${tr("Email")}</label>
        <input class="add-input" id="acs-email" name="acs-email"
               type="email" placeholder="${tr("Email")}"
               autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">

        <label class="add-label" for="acs-role">${tr("Role")}</label>
        <select class="add-input add-select" id="acs-role" name="acs-role">
          <option value="">${tr("Select role…")}</option>
          <option value="Captain">${tr("Captain")}</option>
          <option value="First Mate">${tr("First Mate")}</option>
          <option value="Mate">${tr("Mate")}</option>
          <option value="Deck Officer">${tr("Deck Officer")}</option>
          <option value="Deckhand">${tr("Deckhand")}</option>
          <option value="Engineer">${tr("Engineer")}</option>
          <option value="Chief Engineer">${tr("Chief Engineer")}</option>
          <option value="Navigator">${tr("Navigator")}</option>
          <option value="Boatswain">${tr("Boatswain")}</option>
          <option value="Steward">${tr("Steward")}</option>
          <option value="Stewardess">${tr("Stewardess")}</option>
          <option value="Cook">${tr("Cook")}</option>
          <option value="Marina Staff">${tr("Marina Staff")}</option>
          <option value="Harbor Master">${tr("Harbor Master")}</option>
          <option value="Pilot">${tr("Pilot")}</option>
          <option value="Guest">${tr("Guest")}</option>
          <option value="Owner">${tr("Owner")}</option>
        </select>

        <label class="add-label" for="acs-notes">${tr("Notes")}</label>
        <textarea class="add-input" id="acs-notes" name="acs-notes"
                  placeholder="${tr("Notes")}" rows="3"
                  autocomplete="off" spellcheck="false"></textarea>
      </div>

      <button type="submit" class="add-save" id="acs-save">${tr("+ Add Crew")}</button>
    </form>
  `;

  document.getElementById('modalRoot').append(backdrop, sheet);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  const close = () => {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); sheet.remove(); }, 220);
  };

  backdrop.addEventListener('click', close);
  sheet.querySelector('[data-sheet-close]').addEventListener('click', close);

  const form = sheet.querySelector('#acsForm');
  const save = sheet.querySelector('#acs-save');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name  = sheet.querySelector('#acs-name').value.trim();
    const email = sheet.querySelector('#acs-email').value.trim();
    const role  = sheet.querySelector('#acs-role').value.trim();
    const notes = sheet.querySelector('#acs-notes').value.trim();

    if (!name)  { sheet.querySelector('#acs-name').focus(); return; }
    if (!email) { sheet.querySelector('#acs-email').focus(); return; }
    if (!role)  { sheet.querySelector('#acs-role').focus(); return; }

    save.disabled = true;
    save.textContent = tr('Adding…');

    try {
      await createCrew({ name, email, role, notes });
      close();
      toast(tr(`Crew added: ${name}`), { kind: 'success' });
    } catch (err) {
      console.error('[add crew] failed', err);
      save.disabled = false;
      save.textContent = tr('+ Add Crew');
      let errEl = sheet.querySelector('.add-error');
      if (!errEl) {
        errEl = document.createElement('div');
        errEl.className = 'add-error';
        form.insertBefore(errEl, save);
      }
      errEl.textContent = err.message || itUI('Failed to add crew member.');
    }
  });
}

/* ============================================================
   CREATE
   ============================================================ */
async function createCrew({ name, email, role, notes }) {
  const clientId = Number(store.activeClientId);
  const uid = store.authUser?.uid;
  const userId = store.userProfile?.userId;
  if (!clientId || !uid) throw new Error(tr('No active client'));

  // Find active boat to associate
  const yachtMode = store.activeMarina?.clientType === 'yacht_operator';
  let boatId = Number(store.assignedYacht?.id || 0);
  if (yachtMode && !boatId) throw new Error(tr('No assigned yacht'));
  if (!boatId) try {
    const boatsSnap = await getDocs(
      query(
        collection(db, 'boats'),
        where('clientId', '==', clientId),
        where('isActive', '==', true)
      )
    );
    if (!boatsSnap.empty) {
      boatId = Number(boatsSnap.docs[0].data().id || 0);
    }
  } catch { /* ignore */ }

  if (Number(store.activeClientId) !== clientId || store.authUser?.uid !== uid) {
    throw new Error(tr('The workspace changed. Open Add Crew again.'));
  }
  return createCrewMember(clientId, boatId, userId, { name, email, role, notes });
}
