import { parseBoatCsv, captureBoatImportContext, isBoatImportContextCurrent } from '../util/BoatCsv.js';
import { store } from '../store.js';
import { sheetCloseButton } from '../ui/sheetClose.js';
import { italianUI as itUI } from '../i18n.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
import { t, getLocale, languagePicker } from '../i18n.js';
// js/components/AddBoatSheet.js
// Two views in one sheet (Options → Form) + CSV info sheet
// Supports two modes:
//   - ADD  (no boat passed)  → "Boat Details" + "Save Boat"  + onSaveSingle
//   - EDIT (boat passed)     → "Edit Boat"    + "Update Boat" + onUpdateSingle

const ICONS = {
  add: `
    <svg class="add-icon" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round">
      <line x1="12" y1="5" x2="12" y2="19"/>
      <line x1="5" y1="12" x2="19" y2="12"/>
    </svg>`,
  upload: `
    <svg class="add-icon" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="1.8"
         stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="17 8 12 3 7 8"/>
      <line x1="12" y1="3" x2="12" y2="15"/>
    </svg>`,
  chevron: `
    <svg class="add-chevron" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round">
      <polyline points="9 6 15 12 9 18"/>
    </svg>`
};

const BASE_STATUS_OPTIONS = ['In Service', 'Off Service', 'Maintenance'];

/**
 * @param {Object} opts
 * @param {import('../models/Boat.js').Boat} [opts.boat]   If provided, opens in EDIT mode
 * @param {Function} opts.onSaveSingle  (fields) => Promise   (ADD mode)
 * @param {Function} [opts.onUpdateSingle] (fields) => Promise   (EDIT mode)
 * @param {Function} [opts.onBulkImport]
 */
export function showAddBoatSheet(opts = {}) {
  const { boat, onSaveSingle, onUpdateSingle, onBulkImport } = opts;
  const isEditMode = !!boat;
  const importContext = captureBoatImportContext(store);

  const backdrop = document.createElement('div');
  backdrop.className = 'sheet-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'sheet';
sheet.innerHTML = `
  <button type="button" id="boatSheetClose" aria-label="${tr("Close boat sheet")}"
    style="position:absolute;right:8px;top:8px;z-index:3;width:44px;height:44px;padding:0;border:0;border-radius:8px;background:transparent;color:#F5F7F9;font-size:28px;cursor:pointer;">
    &times;
  </button>
  <div id="addBoatBody"></div>
`;
sheet.style.position = 'fixed';

  document.getElementById('modalRoot').append(backdrop, sheet);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  const close = () => {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); sheet.remove(); }, 220);
  };

  backdrop.addEventListener('click', close);
  sheet.querySelector('#boatSheetClose').addEventListener('click', close);

  const body = sheet.querySelector('#addBoatBody');

  /* ---------- Options (only in ADD mode) ---------- */
  function renderOptions() {
    body.innerHTML = `
      <div class="sheet-title" style="text-align:center;">${t("Add Boat")}</div>

      <div class="add-option" id="optSingle">
        <div class="add-option-icon">${ICONS.add}</div>
        <div class="add-option-text">
          <div class="add-option-title">${t("Add Single Boat")}</div>
          <div class="add-option-sub">${t("Add one boat manually with all details")}</div>
        </div>
        ${ICONS.chevron}
      </div>

      <div class="add-option" id="optBulk" style="margin-top:8px;">
        <div class="add-option-icon">${ICONS.upload}</div>
        <div class="add-option-text">
          <div class="add-option-title">${t("Bulk Import")}</div>
          <div class="add-option-sub">${t("Import multiple boats from CSV file")}</div>
        </div>
        ${ICONS.chevron}
      </div>
    `;

    body.querySelector('#optSingle').addEventListener('click', () => renderForm());
    body.querySelector('#optBulk').addEventListener('click', () => {
      if (onBulkImport) { close(); onBulkImport(); }
      else renderCsvInfo();
    });
  }

  /* ---------- CSV info ---------- */
  function renderCsvInfo() {
    body.innerHTML = `
      <div class="sheet-title" style="text-align:center;">${tr("Import from CSV")}</div>

      <div class="csv-info-scroll">
        <p class="csv-info-intro">${tr("Your CSV file should have a")}<b>${tr("header row")}</b>${t("and")}<b>${tr("comma-separated columns")}</b>${tr("matched by column name (any order):")}</p>

        <ul class="csv-info-list">
          <li><b>name</b>${tr("— Boat name")}<span class="csv-req">${tr("(required)")}</span></li>
          <li><b>type</b>${tr("— Vessel type")}</li>
          <li><b>model</b>${tr("— Model number")}</li>
          <li><b>hin</b>${tr("— HIN number")}</li>
          <li><b>mmsi</b>${tr("— MMSI number")}</li>
          <li><b>port</b>${tr("— Home port")}</li>
          <li><b>status</b>${tr("— In Service / Off Service / Maintenance")}</li>
          <li><b>length, beam, draft, airDraft</b> — Optional dimensions in metres</li>
          <li><b>customerId</b> — Optional existing customer ID from this marina</li>
          <li><b>engineType, engineHours</b> — Optional engine details</li>
        </ul>
        <p>Blank optional numbers are saved as 0 (unknown). Use decimal points; no units or thousands separators. The original seven-column template still works. Invalid rows are reported; matching MMSIs are skipped.</p>

        <div class="csv-info-example-label">${tr("Example:")}</div>
        <pre class="csv-info-example">name,type,model,hin,mmsi,port,status,length,beam,draft,airDraft,customerId,engineType,engineHours
Sea Ray,Sport,270,ABC123,123456789,Monaco,In Service,8.2,2.6,0.9,3.1,,Diesel,120
Bayliner,Cruiser,285,XYZ789,987654321,Miami,Maintenance,8.7,3,0.9,,,,</pre>
      </div>

      <div class="csv-info-actions">
        <button type="button" class="csv-btn csv-btn--cancel" id="csvCancel">${t("Cancel")}</button>
        <button type="button" class="csv-btn csv-btn--choose" id="csvChoose">${tr("Choose File")}</button>
      </div>
    `;

    body.querySelector('#csvCancel').addEventListener('click', () => close());
    body.querySelector('#csvChoose').addEventListener('click', () => {
      close();
      pickAndImportCsv(importContext);
    });
  }

  /* ---------- Form (used for both Add + Edit) ---------- */
  function renderForm() {
    const title  = isEditMode ? t('Edit Boat') : t('Boat Details');
    const btnTxt = isEditMode ? itUI('Update Boat') : itUI('Save Boat');

    // Build status options — in edit mode, add the current value if non-standard
    let statusOptions = [...BASE_STATUS_OPTIONS];
    if (isEditMode && boat.status && !statusOptions.includes(boat.status)) {
      statusOptions = [boat.status, ...statusOptions];
    }

    // Prefill helper — empty string if value is 0 / null / undefined
    const prefill = (v) => {
      if (v === null || v === undefined) return '';
      if (typeof v === 'number' && v === 0) return '';
      return String(v);
    };

    body.innerHTML = `
      <div class="sheet-title" style="text-align:center;">${title}</div>

      <form id="addBoatForm" class="add-form" novalidate>
        <div class="add-scroll">

          <input class="add-input" id="f-name"  type="text" placeholder="${tr("Boat Name *")}"
                 autocomplete="off" autocapitalize="words"
                 value="${isEditMode ? escapeAttr(prefill(boat.name)) : ''}">

          <input class="add-input" id="f-type"  type="text" placeholder="${tr("Boat Type")}"
                 autocomplete="off" autocapitalize="words"
                 value="${isEditMode ? escapeAttr(prefill(boat.type)) : ''}">

          <div class="add-section-title">${t("Vessel Dimensions")}</div>
          <div class="add-section-sub">${tr("Optional • used for berth compatibility checks")}</div>

          <div class="add-row-2">
            <input class="add-input" id="f-length" type="number" step="0.1" placeholder="${t("Length (m)")}"
                   value="${isEditMode ? escapeAttr(prefill(boat.length)) : ''}">
            <input class="add-input" id="f-beam"   type="number" step="0.1" placeholder="${tr("Beam (m)")}"
                   value="${isEditMode ? escapeAttr(prefill(boat.beam)) : ''}">
          </div>

          <div class="add-row-2">
            <input class="add-input" id="f-draft"    type="number" step="0.1" placeholder="${tr("Draft (m)")}"
                   value="${isEditMode ? escapeAttr(prefill(boat.draft)) : ''}">
            <input class="add-input" id="f-airDraft" type="number" step="0.1" placeholder="${tr("Air Draft (m)")}"
                   value="${isEditMode ? escapeAttr(prefill(boat.airDraft)) : ''}">
          </div>

          <input class="add-input" id="f-engineType" type="text" placeholder="${tr("Engine Type")}"
                 autocomplete="off" autocapitalize="words"
                 value="${isEditMode ? escapeAttr(prefill(boat.engineType)) : ''}">

          <input class="add-input" id="f-hin"  type="text" placeholder="${tr("HIN Number")}"
                 autocomplete="off" style="text-transform:uppercase;"
                 value="${isEditMode ? escapeAttr(prefill(boat.hin)) : ''}">

          <input class="add-input" id="f-mmsi" type="text" placeholder="MMSI"
                 inputmode="numeric" autocomplete="off"
                 value="${isEditMode ? escapeAttr(prefill(boat.mmsi)) : ''}">

          <input class="add-input" id="f-port" type="text" placeholder="${tr("Port Name")}"
                 autocomplete="off" autocapitalize="words"
                 value="${isEditMode ? escapeAttr(prefill(boat.port)) : ''}">

          <div class="add-section-title" style="margin-top:20px;">${t("Status")}</div>
          <select class="add-input add-select" id="f-status">
            ${statusOptions.map(s => {
              const selected = isEditMode && s === boat.status ? 'selected' : '';
              return `<option value="${escapeAttr(s)}" ${selected}>${escapeHtml(s)}</option>`;
            }).join('')}
          </select>

          <label class="add-checkbox" style="margin-top:16px;">
            <input type="checkbox" id="f-setActive"
                   ${isEditMode ? (boat.isActive ? 'checked' : '') : 'checked'}>
            <span>${t("Set as active boat")}</span>
          </label>
        </div>

        <button type="submit" class="add-save" id="f-save">${btnTxt}</button>
      </form>
    `;

    const form = body.querySelector('#addBoatForm');
    const name = body.querySelector('#f-name');
    const save = body.querySelector('#f-save');

    // In ADD mode → start disabled; in EDIT mode → start enabled (name prefilled)
    save.disabled = isEditMode ? false : name.value.trim().length === 0;

    // Enable / disable as user types (matches Android)
    name.addEventListener('input', () => {
      save.disabled = name.value.trim().length === 0;
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (save.disabled) return;

      const fields = {
        name:       body.querySelector('#f-name').value.trim(),
        type:       body.querySelector('#f-type').value.trim() || 'Unknown',
        engineType: body.querySelector('#f-engineType').value.trim() || 'Unknown',
        hin:        body.querySelector('#f-hin').value.trim() || 'TBC',
        mmsi:       body.querySelector('#f-mmsi').value.trim() || 'TBC',
        port:       body.querySelector('#f-port').value.trim() || 'TBC',
        status:     body.querySelector('#f-status').value,
        isActive:   body.querySelector('#f-setActive').checked,
        customerId: isEditMode ? boat.customerId : 0,
        length:     parseFloat(body.querySelector('#f-length').value) || 0,
        beam:       parseFloat(body.querySelector('#f-beam').value) || 0,
        draft:      parseFloat(body.querySelector('#f-draft').value) || 0,
        airDraft:   parseFloat(body.querySelector('#f-airDraft').value) || 0
      };

      save.disabled = true;
      save.textContent = isEditMode ? 'Updating…' : tr('Saving…');

      try {
        if (isEditMode) {
          await onUpdateSingle(fields);
        } else {
          await onSaveSingle(fields);
        }
        close();
      } catch (err) {
        console.error('[boat form] failed', err);
        save.disabled = false;
        save.textContent = btnTxt;
        let errEl = body.querySelector('.add-error');
        if (!errEl) {
          errEl = document.createElement('div');
          errEl.className = 'add-error';
          form.insertBefore(errEl, save);
        }
        errEl.textContent = err.message || tr('Failed to save.');
      }
    });
  }

  // Route to correct view
  if (isEditMode) renderForm();
  else renderOptions();
}

/* ============================================================
   CSV IMPORT
   ============================================================ */
function pickAndImportCsv(context) {
  if (!isBoatImportContextCurrent(store, context)) {
    showResultModal({ success: 0, skipped: 0, failed: 1,
      errors: [tr('Your marina or session changed. Reopen the boat import.')] });
    return;
  }
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.csv,.txt,text/csv';
  input.style.display = 'none';

  input.addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    input.remove();
    if (!file) return;

    try {
      const text = await file.text();
      if (!isBoatImportContextCurrent(store, context)) return;
      const rows = parseBoatCsv(text);

      if (!rows.length) {
        showResultModal({
          success: 0, skipped: 0, failed: 0,
          errors: ['No valid rows found in file.']
        });
        return;
      }

      await runImportWithProgress(rows, context);
    } catch (err) {
      console.error('[csv] read failed', err);
      showResultModal({
        success: 0, skipped: 0, failed: 1,
        errors: [err.message || itUI('Failed to read file.')]
      });
    }
  });

  document.body.appendChild(input);
  input.click();
}

async function runImportWithProgress(rows, context) {
  const { importBoatsFromRows } = await import('../db.js');
  const { toast } = await import('../ui/toast.js');

  const backdrop = document.createElement('div');
  backdrop.className = 'confirm-backdrop is-open';

  const sheet = document.createElement('div');
  sheet.className = 'confirm-sheet is-open';
  sheet.innerHTML = `
    <div class="confirm-title">${tr("Importing boats…")}</div>
    <div class="confirm-message" id="importProgress">${tr("Starting…")}</div>
    <div class="import-bar-wrap">
      <div class="import-bar" id="importBar"></div>
    </div>
  `;

  document.getElementById('modalRoot').append(backdrop, sheet);

  const progressEl = sheet.querySelector('#importProgress');
  const barEl      = sheet.querySelector('#importBar');

  try {
    const userId = store.userProfile?.userId || 0;
    const clientId = context.clientId;
    const isCurrent = () => isBoatImportContextCurrent(store, context);

    const result = await importBoatsFromRows(
      clientId,
      userId,
      rows,
      (done, skipped, total, failed = 0) => {
        const processed = done + skipped + failed;
        const pct = Math.round((processed / total) * 100);
        progressEl.textContent = `${processed} of ${total}  ·  ${done} added, ${skipped} skipped`;
        barEl.style.width = pct + '%';
      },
      isCurrent
    );

    progressEl.textContent = tr('Done');
    barEl.style.width = '100%';

    await new Promise((r) => setTimeout(r, 300));

    backdrop.remove();
    sheet.remove();

    if (!isCurrent()) return;
    showResultModal(result);

    if (result.success > 0) {
      toast(tr(`Imported ${result.success} boat${result.success === 1 ? '' : 's'}`),
            { kind: 'success' });
    }
  } catch (err) {
    console.error('[import] failed', err);
    backdrop.remove();
    sheet.remove();
    if (!isBoatImportContextCurrent(store, context)) return;
    showResultModal({
      success: 0, skipped: 0, failed: 1,
      errors: [err.message || itUI('Import failed.')]
    });
  }
}

function showResultModal({ success, skipped, failed, errors = [] }) {
  const backdrop = document.createElement('div');
  backdrop.className = 'confirm-backdrop';

  const sheet = document.createElement('div');
  sheet.className = 'confirm-sheet';
  sheet.innerHTML = `
    ${sheetCloseButton()}
    <div class="confirm-title">${tr("Import complete")}</div>

    <div class="import-stats">
      <div class="import-stat">
        <div class="import-stat-value ok">${success}</div>
        <div class="import-stat-label">${tr("Added")}</div>
      </div>
      <div class="import-stat">
        <div class="import-stat-value skip">${skipped}</div>
        <div class="import-stat-label">${tr("Skipped")}</div>
      </div>
      <div class="import-stat">
        <div class="import-stat-value fail">${failed}</div>
        <div class="import-stat-label">${tr("Failed")}</div>
      </div>
    </div>

    ${errors.length ? `
      <div class="import-errors">
        <div class="import-errors-title">${tr("Errors")}</div>
        ${errors.slice(0, 10).map(e => `<div class="import-error-line">• ${escapeHtml(e)}</div>`).join('')}
        ${errors.length > 10 ? `<div class="import-error-line">${itUI("…and")} ${errors.length - 10} ${itUI("more")}</div>` : ''}
      </div>
    ` : ''}

    <div class="confirm-actions">
      <button class="confirm-btn confirm-btn--cancel" id="closeImportResult"
              style="flex:1;">${t("Close")}</button>
    </div>
  `;

  document.getElementById('modalRoot').append(backdrop, sheet);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    sheet.classList.add('is-open');
  });

  const close = () => {
    backdrop.classList.remove('is-open');
    sheet.classList.remove('is-open');
    setTimeout(() => { backdrop.remove(); sheet.remove(); }, 220);
  };

  backdrop.addEventListener('click', close);
  sheet.querySelector('[data-sheet-close]').addEventListener('click', close);
  sheet.querySelector('#closeImportResult').addEventListener('click', close);
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function escapeAttr(s) {
  return String(s ?? '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
