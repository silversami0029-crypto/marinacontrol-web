import { showEditProfileSheet } from './EditProfileSheet.js';
import { t as tr, getLocale as uiLocale } from '../i18n.js';
import { t, getLocale, languagePicker } from '../i18n.js';
// js/screens/AccountScreen.js
// Account — mirrors activity_account.xml + AccountFragment.java

import { showManageMarinasSheet } from './ManageMarinasSheet.js';
import { store } from '../store.js';
import { auth } from '../firebase.js';
import { signOut } from '../firebase.js';
import { confirmSheet } from '../ui/confirm.js';
import { toast } from '../ui/toast.js';
import { db, doc, getDoc, deleteDoc } from '../firebase.js';

const ICONS = {
  anchor: `
   <svg xmlns="http://www.w3.org/2000/svg"
     viewBox="0 0 960 960" width="20" height="20"
     fill="currentColor" style="color:#AEB6C1;"
     aria-hidden="true">
      <path d="M355,858Q291,836 239,798Q187,760 153.5,709Q120,658 120,600L120,480L280,600L218,662Q247,713 310,750Q373,787 440,797L440,440L320,440L320,360L440,360L440,313Q405,300 382.5,269.5Q360,239 360,200Q360,150 395,115Q430,80 480,80Q530,80 565,115Q600,150 600,200Q600,239 577.5,269.5Q555,300 520,313L520,360L640,360L640,440L520,440L520,797Q587,787 650,750Q713,713 742,662L680,600L840,480L840,600Q840,658 806.5,709Q773,760 721,798Q669,836 605,858Q541,880 480,880Q419,880 355,858ZM480,240Q497,240 508.5,228.5Q520,217 520,200Q520,183 508.5,171.5Q497,160 480,160Q463,160 451.5,171.5Q440,183 440,200Q440,217 451.5,228.5Q463,240 480,240Z"/>
    </svg>`,

  person: `
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
         stroke="currentColor" stroke-width="1.8"
         stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="8" r="4"/>
      <path d="M4 21a8 8 0 0 1 16 0"/>
    </svg>`,
  delete: `
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
         stroke="currentColor" stroke-width="1.8"
         stroke-linecap="round" stroke-linejoin="round">
      <path d="M3 6h18"/>
      <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      <path d="M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/>
      <line x1="10" y1="11" x2="10" y2="17"/>
      <line x1="14" y1="11" x2="14" y2="17"/>
    </svg>`,
  logout: `
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
         stroke="currentColor" stroke-width="1.8"
         stroke-linecap="round" stroke-linejoin="round">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
      <polyline points="16 17 21 12 16 7"/>
      <line x1="21" y1="12" x2="9" y2="12"/>
    </svg>`,
  chevron: `
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none"
         stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round">
      <polyline points="9 6 15 12 9 18"/>
    </svg>`
};


export function mountAccountScreen() {
  const screen = document.getElementById('screen');
  const profile = store.userProfile || {};

  const name  = profile.name || store.authUser?.displayName || profile.email || store.authUser?.email || t('User');
  const email = profile.email || store.authUser?.email || '';
  const initials = computeInitials(name);

  screen.innerHTML = `
    <div class="account-wrap">

      <!-- Header pill -->
      <div class="account-header">
        <div class="account-pill">${t("My Account")}</div>
      </div>

      <!-- User info card -->
      <div class="account-card">
        <div class="account-user-row">
          <div class="account-avatar">${escapeHtml(initials)}</div>
          <div class="account-user-info">
            <div class="account-user-name">${escapeHtml(name)}</div>
            <div class="account-user-email">${escapeHtml(email)}</div>
          </div>
        </div>
      </div>

      <div class="account-card">${languagePicker()}</div>
      <!-- Menu card -->
      <div class="account-card account-menu">
        <button class="account-item" id="btnEditProfile">
          <span class="account-item-icon">${ICONS.person}</span>
          <span class="account-item-text">${t("Edit Profile")}</span>
          <span class="account-item-chevron">${ICONS.chevron}</span>
        </button>

        <button type="button" class="account-item" id="btnManageMarinas">
          <span class="account-item-icon">${ICONS.anchor}</span>
          <span class="account-item-text">${t("Manage Marinas")}</span>
          <span class="account-item-chevron">${ICONS.chevron}</span>
        </button>

        <button class="account-item account-item--danger" id="btnDeleteAccount">
          <span class="account-item-icon">${ICONS.delete}</span>
          <span class="account-item-text">${t("Delete Account")}</span>
          <span class="account-item-chevron">${ICONS.chevron}</span>
        </button>

        <button class="account-item account-item--danger" id="btnLogout">
          <span class="account-item-icon">${ICONS.logout}</span>
          <span class="account-item-text">${t("Logout")}</span>
          <span class="account-item-chevron">${ICONS.chevron}</span>
        </button>
      </div>

      
  `;

  document.getElementById('btnEditProfile').addEventListener('click', () => {
    showEditProfileSheet(() => { if (location.hash.split('?')[0] === '#/account') mountAccountScreen(); });
  });

  document.getElementById('btnManageMarinas').addEventListener('click', showManageMarinasSheet);
  document.getElementById('btnDeleteAccount').addEventListener('click', onDeleteAccount);
  document.getElementById('btnLogout').addEventListener('click', onLogout);
}

/* ---------- Helpers ---------- */
function computeInitials(name) {
  const clean = String(name || '').trim();
  if (!clean) return '?';
  const parts = clean.split(/\s+/);
  if (parts.length === 1) {
    return parts[0].substring(0, Math.min(2, parts[0].length)).toUpperCase();
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

async function onDeleteAccount() {
  const ok = await confirmSheet({
    title: t("Delete Account"),
    message: t("This will permanently delete your account data. This action cannot be undone."),
    confirmText: t("Delete"),
    cancelText: t("Cancel")
  });
  if (!ok) return;

  try {
    const uid = store.authUser?.uid;
    if (!uid) throw new Error(tr('No authenticated user'));

    // Find the users doc matching this firebaseUid and delete it
    const { collection, query, where, getDocs } = await import('../firebase.js');
    const q = query(collection(db, 'users'), where('firebaseUid', '==', uid));
    const snap = await getDocs(q);

    for (const d of snap.docs) {
      await deleteDoc(d.ref);
    }

    toast(tr('Account deleted'), { kind: 'success' });

    // Sign out → router will redirect to /login
    await signOut(auth);

  } catch (err) {
    console.error('[delete account] failed', err);
    toast(tr('Failed to delete account'), { kind: 'error' });
  }
}

async function onLogout() {
  const ok = await confirmSheet({
    title: t("Log out"),
    message: t("Are you sure you want to log out of MarinaControl?"),
    confirmText: t("Log out"),
    cancelText: t("Cancel")
  });
  if (!ok) return;

  try {
    await signOut(auth);
    toast(t("Signed out"));
    // router will redirect to /login automatically
  } catch (err) {
    console.error('[logout] failed', err);
    toast(t("Failed to log out"), { kind: 'error' });
  }
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}